package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.PersianDastgah
import com.example.model.HardwareTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Saleh ORG Pa5X", appName)
    }

    @Test
    fun `verify persian dastgah shor microtonal tuning`() {
        val shor = PersianDastgah.SHOR
        assertNotNull(shor)
        // Degree 4 (E) should be Koron (-50 cents)
        assertEquals(-50, shor.centsOffsets[4])
        // Degree 10 (B flat) should be Koron (-50 cents)
        assertEquals(-50, shor.centsOffsets[10])
    }

    @Test
    fun `verify hardware tiers`() {
        assertEquals(3, HardwareTier.values().size)
        assertEquals(22050, HardwareTier.TIER_3.sampleRate)
        assertEquals(44100, HardwareTier.TIER_1.sampleRate)
    }
}
