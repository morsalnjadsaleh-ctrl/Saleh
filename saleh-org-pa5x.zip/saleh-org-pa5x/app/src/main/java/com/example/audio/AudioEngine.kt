package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.HardwareTier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/**
 * High-performance native PCM Audio Engine with:
 * - Dynamic pitch-shifting acoustic Grand Piano synthesis out-of-the-box
 * - 3-tier hardware scaling (Mono 22kHz on budget Tier 3, High-res Stereo on Tier 1 & 2)
 * - Low-latency polyphony mixer
 * - Built-in drum synth mapped to Standard MIDI drum note numbers
 */
class AudioEngine(private val coroutineScope: CoroutineScope) {

    private var audioTrack: AudioTrack? = null
    private var renderJob: Job? = null
    private val isRunning = AtomicBoolean(false)

    var currentTier: HardwareTier = HardwareTier.TIER_1
        private set

    // Active playing piano voices: key = voiceId, value = ActiveVoice
    private val activeVoices = ConcurrentHashMap<Int, PianoVoice>()
    private var voiceIdCounter = 0

    // Active drum trigger events
    private val activeDrumHits = ConcurrentHashMap<Int, DrumVoice>()
    private var drumIdCounter = 0

    // Active arranger synth voices
    private val activeArrangerVoices = ConcurrentHashMap<Int, ArrangerVoice>()
    private var arrangerIdCounter = 0

    // Master volume (0.0 to 1.0)
    var masterVolume: Float = 0.85f

    init {
        setupAudioTrack(HardwareTier.TIER_1)
    }

    fun setHardwareTier(tier: HardwareTier) {
        if (currentTier == tier && audioTrack != null) return
        currentTier = tier
        stop()
        setupAudioTrack(tier)
        start()
    }

    private fun setupAudioTrack(tier: HardwareTier) {
        try {
            audioTrack?.release()
        } catch (_: Exception) {}

        val sampleRate = tier.sampleRate
        val channelConfig = if (tier.isStereo) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT

        val minBufSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, encoding)
        val bufferSize = (minBufSize * 2).coerceAtLeast(1024)

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setChannelMask(channelConfig)
            .setEncoding(encoding)
            .build()

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
    }

    fun start() {
        if (isRunning.getAndSet(true)) return
        try {
            audioTrack?.play()
        } catch (_: Exception) {}

        renderJob = coroutineScope.launch(Dispatchers.Default) {
            val isStereo = currentTier.isStereo
            val sampleRate = currentTier.sampleRate
            val chunkSize = if (currentTier == HardwareTier.TIER_3) 256 else 384
            val bufferSamples = if (isStereo) chunkSize * 2 else chunkSize
            val pcmBuffer = ShortArray(bufferSamples)

            while (isActive && isRunning.get()) {
                val dt = 1.0 / sampleRate

                for (i in 0 until chunkSize) {
                    var leftSample = 0.0f
                    var rightSample = 0.0f

                    // 1. Render active Grand Piano voices with dynamic pitch shifting
                    val voiceIter = activeVoices.entries.iterator()
                    while (voiceIter.hasNext()) {
                        val entry = voiceIter.next()
                        val voice = entry.value
                        val sampleVal = voice.nextSample(dt)
                        if (voice.isFinished) {
                            voiceIter.remove()
                        } else {
                            leftSample += sampleVal * voice.panLeft
                            rightSample += sampleVal * voice.panRight
                        }
                    }

                    // 2. Render active Arranger percussion & accompaniment voices
                    val drumIter = activeDrumHits.entries.iterator()
                    while (drumIter.hasNext()) {
                        val entry = drumIter.next()
                        val drum = entry.value
                        val sampleVal = drum.nextSample(dt)
                        if (drum.isFinished) {
                            drumIter.remove()
                        } else {
                            leftSample += sampleVal * drum.panLeft
                            rightSample += sampleVal * drum.panRight
                        }
                    }

                    // 3. Render active Arranger harmonic accompaniment tracks (Bass, ACC1-ACC5)
                    val arrIter = activeArrangerVoices.entries.iterator()
                    while (arrIter.hasNext()) {
                        val entry = arrIter.next()
                        val arrVoice = entry.value
                        val sampleVal = arrVoice.nextSample(dt)
                        if (arrVoice.isFinished) {
                            arrIter.remove()
                        } else {
                            leftSample += sampleVal * arrVoice.panLeft
                            rightSample += sampleVal * arrVoice.panRight
                        }
                    }

                    // Master output scaling with soft saturation limiter
                    val vol = masterVolume
                    val clampedLeft = (leftSample * vol).coerceIn(-1.0f, 1.0f)
                    val clampedRight = (rightSample * vol).coerceIn(-1.0f, 1.0f)

                    if (isStereo) {
                        pcmBuffer[i * 2] = (clampedLeft * 32767.0f).toInt().toShort()
                        pcmBuffer[i * 2 + 1] = (clampedRight * 32767.0f).toInt().toShort()
                    } else {
                        val monoSample = ((clampedLeft + clampedRight) * 0.5f).coerceIn(-1.0f, 1.0f)
                        pcmBuffer[i] = (monoSample * 32767.0f).toInt().toShort()
                    }
                }

                audioTrack?.write(pcmBuffer, 0, bufferSamples)
            }
        }
    }

    fun stop() {
        isRunning.set(false)
        renderJob?.cancel()
        renderJob = null
        try {
            audioTrack?.pause()
            audioTrack?.flush()
        } catch (_: Exception) {}
        activeVoices.clear()
        activeDrumHits.clear()
        activeArrangerVoices.clear()
    }

    /**
     * Triggers dynamic pitch-shifted Grand Piano note out-of-the-box
     * @param midiNote standard MIDI note (60 = Middle C)
     * @param velocity 0..127 key velocity
     * @param microtonalCents quarter-tone tuning offset (-50 cents for Koron, +50 for Sori)
     */
    fun noteOn(midiNote: Int, velocity: Int = 100, microtonalCents: Int = 0): Int {
        val id = ++voiceIdCounter
        // Dynamic pitch shifting formula based on standard A4 = 440 Hz
        val semitones = (midiNote - 69) + (microtonalCents / 100.0)
        val frequency = 440.0 * 2.0.pow(semitones / 12.0)
        
        // Panning slightly across keyboard (low notes left, high notes right)
        val pan = ((midiNote - 36).toFloat() / 52.0f).coerceIn(0.1f, 0.9f)
        val panL = if (currentTier.isStereo) kotlin.math.cos(pan * (PI.toFloat() / 2f)) else 0.707f
        val panR = if (currentTier.isStereo) kotlin.math.sin(pan * (PI.toFloat() / 2f)) else 0.707f

        val voice = PianoVoice(
            frequency = frequency,
            velocity = velocity.coerceIn(1, 127) / 127.0f,
            tier = currentTier,
            panLeft = panL,
            panRight = panR
        )
        activeVoices[id] = voice
        return id
    }

    fun noteOff(voiceId: Int) {
        activeVoices[voiceId]?.release()
    }

    /**
     * Play drum hit using virtual drum kit note mapper (MIDI note 36..51)
     */
    fun triggerDrum(midiNote: Int, velocity: Float = 0.85f, trackVol: Float = 1.0f) {
        val id = ++drumIdCounter
        val drum = DrumVoice(midiNote, velocity * trackVol, currentTier)
        activeDrumHits[id] = drum
    }

    /**
     * Play arranger accompaniment note (Bass, ACC1-ACC5)
     */
    fun triggerArrangerNote(midiNote: Int, type: ArrangerTrackType, velocity: Float, durationSec: Double, volume: Float) {
        val id = ++arrangerIdCounter
        val semitones = midiNote - 69
        val frequency = 440.0 * 2.0.pow(semitones / 12.0)
        val voice = ArrangerVoice(frequency, type, velocity * volume, durationSec, currentTier)
        activeArrangerVoices[id] = voice
    }
}

/**
 * Dynamic Grand Piano physical modeling voice:
 * Generates acoustic piano hammer transient, multi-harmonic resonance, and natural exponential decay.
 */
class PianoVoice(
    val frequency: Double,
    val velocity: Float,
    val tier: HardwareTier,
    val panLeft: Float,
    val panRight: Float
) {
    private var phase = 0.0
    private var phase2 = 0.0
    private var phase3 = 0.0
    private var phase4 = 0.0
    private var time = 0.0
    private var isReleasing = false
    private var releaseTime = 0.0
    var isFinished = false
        private set

    // Envelope parameters
    private val attackTime = 0.005 // 5ms crisp strike
    private val decayRate = when {
        frequency < 130.0 -> 0.45  // Deep bass notes ring long
        frequency < 400.0 -> 0.85  // Mid notes
        else -> 1.8                // High notes decay faster
    }

    fun release() {
        if (!isReleasing) {
            isReleasing = true
            releaseTime = time
        }
    }

    fun nextSample(dt: Double): Float {
        time += dt

        // Amplitude envelope
        val ampEnv: Double = if (time < attackTime) {
            time / attackTime
        } else {
            exp(-decayRate * (time - attackTime))
        }

        val releaseEnv: Double = if (isReleasing) {
            val rTime = time - releaseTime
            val relDuration = 0.08
            if (rTime >= relDuration) {
                isFinished = true
                return 0.0f
            }
            1.0 - (rTime / relDuration)
        } else {
            1.0
        }

        if (ampEnv < 0.0005) {
            isFinished = true
            return 0.0f
        }

        // Acoustic Grand Piano multi-harmonic synthesis
        val w1 = 2.0 * PI * frequency
        phase += w1 * dt
        if (phase > 2.0 * PI) phase -= 2.0 * PI

        var s = sin(phase)

        if (tier != HardwareTier.TIER_3) {
            // Harmonics 2, 3, 4 for rich warmth
            val w2 = 2.0 * PI * frequency * 2.001 // slight inharmonicity of piano strings
            phase2 += w2 * dt
            if (phase2 > 2.0 * PI) phase2 -= 2.0 * PI

            val w3 = 2.0 * PI * frequency * 3.003
            phase3 += w3 * dt
            if (phase3 > 2.0 * PI) phase3 -= 2.0 * PI

            val harmonic2 = sin(phase2) * 0.45
            val harmonic3 = sin(phase3) * 0.22

            s += harmonic2 + harmonic3

            // Tier 1 ultra-realistic 4th harmonic & hammer strike transient
            if (tier == HardwareTier.TIER_1) {
                val w4 = 2.0 * PI * frequency * 4.006
                phase4 += w4 * dt
                if (phase4 > 2.0 * PI) phase4 -= 2.0 * PI
                s += sin(phase4) * 0.12

                // Hammer noise transient for the first 12ms
                if (time < 0.012) {
                    val noise = (Math.random() * 2.0 - 1.0) * 0.18 * (1.0 - time / 0.012)
                    s += noise
                }
            }
        }

        val totalAmp = (s * ampEnv * releaseEnv * velocity * 0.65).toFloat()
        return totalAmp
    }
}

/**
 * Virtual Drum Kit sound generator mapped to Korg Pa5X Drum Kit notes:
 * 36: Kick Drum
 * 38: Snare Drum
 * 42: Closed Hi-Hat
 * 46: Open Hi-Hat
 * 37: SideStick / Rimshot
 * 39: Hand Clap
 * 49: Crash Cymbal
 * 51: Ride Cymbal
 * 60..64: Tombak / Daf / Percussion
 */
class DrumVoice(
    val midiNote: Int,
    val velocity: Float,
    val tier: HardwareTier
) {
    private var time = 0.0
    var isFinished = false
        private set

    val panLeft: Float
    val panRight: Float

    init {
        // Spatial drum kit placement
        when (midiNote) {
            36 -> { panLeft = 0.7f; panRight = 0.7f } // Kick center
            38 -> { panLeft = 0.75f; panRight = 0.65f } // Snare slightly left
            42 -> { panLeft = 0.85f; panRight = 0.5f } // Closed HH left
            46 -> { panLeft = 0.85f; panRight = 0.5f } // Open HH left
            49 -> { panLeft = 0.9f; panRight = 0.4f } // Crash left
            51 -> { panLeft = 0.4f; panRight = 0.9f } // Ride right
            39 -> { panLeft = 0.65f; panRight = 0.75f } // Clap
            else -> { panLeft = 0.7f; panRight = 0.7f }
        }
    }

    private var phase = 0.0

    fun nextSample(dt: Double): Float {
        time += dt
        var sample = 0.0

        when (midiNote) {
            // 36: Kick Drum (Sweeping sine 140Hz -> 42Hz)
            36 -> {
                val duration = 0.28
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                val pitch = 45.0 + 100.0 * exp(-time * 28.0)
                phase += 2.0 * PI * pitch * dt
                val env = exp(-time * 11.0)
                sample = sin(phase) * env * 1.2
            }
            // 38: Snare Drum (180Hz tone + snappy noise burst)
            38 -> {
                val duration = 0.22
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                phase += 2.0 * PI * 185.0 * dt
                val body = sin(phase) * exp(-time * 22.0) * 0.6
                val noise = (Math.random() * 2.0 - 1.0) * exp(-time * 16.0) * 0.75
                sample = body + noise
            }
            // 42: Closed Hi-Hat (crisp metallic click)
            42 -> {
                val duration = 0.06
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                val noise = (Math.random() * 2.0 - 1.0) * exp(-time * 55.0) * 0.7
                sample = noise
            }
            // 46: Open Hi-Hat (metallic shimmer decay)
            46 -> {
                val duration = 0.35
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                val noise = (Math.random() * 2.0 - 1.0) * exp(-time * 10.0) * 0.65
                sample = noise
            }
            // 37: SideStick (sharp rim click)
            37 -> {
                val duration = 0.05
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                phase += 2.0 * PI * 750.0 * dt
                sample = sin(phase) * exp(-time * 70.0) * 0.9
            }
            // 39: Hand Clap
            39 -> {
                val duration = 0.18
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                val env = if (time < 0.03) {
                    (sin(time * 600.0) * 0.5 + 0.5) * exp(-time * 15.0)
                } else {
                    exp(-time * 18.0)
                }
                sample = (Math.random() * 2.0 - 1.0) * env * 0.8
            }
            // 49: Crash Cymbal
            49 -> {
                val duration = 0.8
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                sample = (Math.random() * 2.0 - 1.0) * exp(-time * 4.5) * 0.5
            }
            // 51: Ride Cymbal (bell overtone)
            51 -> {
                val duration = 0.55
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                phase += 2.0 * PI * 880.0 * dt
                val bell = sin(phase) * exp(-time * 6.0) * 0.35
                val sizzle = (Math.random() * 2.0 - 1.0) * exp(-time * 9.0) * 0.3
                sample = bell + sizzle
            }
            // Tombak / Daf Persian Percussion (round resonant warm drum tone)
            else -> {
                val duration = 0.25
                if (time >= duration) {
                    isFinished = true
                    return 0.0f
                }
                val freq = if (midiNote % 2 == 0) 110.0 else 230.0 // Dum vs Tek
                phase += 2.0 * PI * freq * dt
                sample = sin(phase) * exp(-time * 14.0) * 0.95
            }
        }

        return (sample * velocity * 0.75).toFloat()
    }
}

enum class ArrangerTrackType {
    BASS, ACC1_PAD, ACC2_ARPEGGIATOR, ACC3_STRINGS, ACC4_LEAD, ACC5_FX
}

/**
 * Arranger accompaniment instrument synthesizer
 */
class ArrangerVoice(
    val frequency: Double,
    val type: ArrangerTrackType,
    val velocity: Float,
    val durationSec: Double,
    val tier: HardwareTier
) {
    private var phase = 0.0
    private var time = 0.0
    var isFinished = false
        private set

    val panLeft: Float = 0.7f
    val panRight: Float = 0.7f

    fun nextSample(dt: Double): Float {
        time += dt
        if (time >= durationSec) {
            isFinished = true
            return 0.0f
        }

        phase += 2.0 * PI * frequency * dt
        if (phase > 2.0 * PI) phase -= 2.0 * PI

        val env = when (type) {
            ArrangerTrackType.BASS -> exp(-time * 4.0)
            ArrangerTrackType.ACC1_PAD -> (1.0 - exp(-time * 12.0)) * exp(-time * 1.2)
            ArrangerTrackType.ACC2_ARPEGGIATOR -> exp(-time * 6.5)
            ArrangerTrackType.ACC3_STRINGS -> (1.0 - exp(-time * 8.0)) * exp(-time * 0.9)
            ArrangerTrackType.ACC4_LEAD -> exp(-time * 3.5)
            ArrangerTrackType.ACC5_FX -> exp(-time * 5.0)
        }

        val s = when (type) {
            ArrangerTrackType.BASS -> {
                // Round bass with subtle sub-harmonics
                sin(phase) * 0.7 + sin(phase * 2.0) * 0.25
            }
            ArrangerTrackType.ACC1_PAD, ArrangerTrackType.ACC3_STRINGS -> {
                // Smooth pad / string wave
                sin(phase) * 0.5 + sin(phase * 2.0) * 0.25 + sin(phase * 3.0) * 0.15
            }
            ArrangerTrackType.ACC2_ARPEGGIATOR -> {
                // Bell/electric piano
                sin(phase) * 0.6 + sin(phase * 3.0) * 0.25
            }
            ArrangerTrackType.ACC4_LEAD -> {
                // Searing lead tone
                val square = if (sin(phase) > 0.0) 0.4 else -0.4
                sin(phase) * 0.5 + square * 0.3
            }
            ArrangerTrackType.ACC5_FX -> {
                sin(phase * 1.5) * 0.4 + sin(phase) * 0.4
            }
        }

        return (s * env * velocity * 0.45).toFloat()
    }
}
