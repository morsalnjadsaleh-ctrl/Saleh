package com.example.model

enum class SetFileType {
    RAW_KORG_SET,      // .SET (Limited to 2 loads in free trial)
    SALEH_ENCRYPTED    // .saleh / .sp5x (Proprietary format, Unlimited loading)
}

data class SetPackage(
    val id: String,
    val name: String,
    val fileName: String,
    val fileType: SetFileType,
    val description: String,
    val author: String,
    val styleCount: Int,
    val soundCount: Int,
    val padCount: Int,
    val fileSizeMb: Double,
    val isEncrypted: Boolean
)
