package com.example.model

enum class HardwareTier(
    val title: String,
    val description: String,
    val sampleRate: Int,
    val isStereo: Boolean,
    val velocityLayers: Int,
    val enableAnimations: Boolean,
    val enable3dEffects: Boolean
) {
    TIER_3(
        title = "TIER 3 (Low-End / Budget)",
        description = "Optimized for budget hardware (A07). Flat 2D textures, mono audio, static UI, zero stutter.",
        sampleRate = 22050,
        isStereo = false,
        velocityLayers = 1,
        enableAnimations = false,
        enable3dEffects = false
    ),
    TIER_2(
        title = "TIER 2 (Mid-Range)",
        description = "Balanced performance. Standard metallic textures, stereo audio, 60fps animations.",
        sampleRate = 44100,
        isStereo = true,
        velocityLayers = 2,
        enableAnimations = true,
        enable3dEffects = false
    ),
    TIER_1(
        title = "TIER 1 (High-End / Flagship)",
        description = "Ultra-realistic 3D brushed chassis, 32-bit hi-fi audio, zero-latency multi-layer velocity & neon lighting.",
        sampleRate = 44100,
        isStereo = true,
        velocityLayers = 4,
        enableAnimations = true,
        enable3dEffects = true
    )
}
