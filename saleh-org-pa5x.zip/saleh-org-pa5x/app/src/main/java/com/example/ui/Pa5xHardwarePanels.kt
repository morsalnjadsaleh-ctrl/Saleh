package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HardwareTier
import com.example.ui.theme.Pa5xButtonBevel
import com.example.ui.theme.Pa5xButtonFace
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xChassisDark
import com.example.ui.theme.Pa5xKnurlDark
import com.example.ui.theme.Pa5xKnurlHighlight
import com.example.ui.theme.Pa5xKnurlSilver
import com.example.ui.theme.Pa5xKorgOrange
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen
import com.example.ui.theme.Pa5xRedDivider
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Official KORG Pa5X Badge with authentic typography and signature glowing orange "X"
 */
@Composable
fun KorgPa5xLogoBadge(
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF0A0C10))
            .border(1.dp, Color(0xFF262630), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Iconic KORG block branding
        Text(
            text = "KORG",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Pa5X Model Badge with glowing ruby-orange "X"
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(Color(0xFF1E212B), RoundedCornerShape(3.dp))
                .border(0.5.dp, Color(0xFF3B4252), RoundedCornerShape(3.dp))
                .padding(horizontal = 5.dp, vertical = 1.5.dp)
        ) {
            Text(
                text = "Pa5",
                color = Color(0xFFE2E8F0),
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "X",
                color = Pa5xKorgOrange,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        Column {
            Text(
                text = "PROFESSIONAL ARRANGER",
                color = Color(0xFF94A3B8),
                fontSize = 7.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "EDS-XP / SALEH ORIENTAL EDITION",
                color = Pa5xNeonAmber,
                fontSize = 6.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * Master Volume Dial with metallic silver knurling and dB scale
 */
@Composable
fun Pa5xMasterVolumeDial(
    volume: Float,
    onVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var vol by remember { mutableFloatStateOf(volume) }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Pa5xChassisCard)
            .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "MASTER",
                color = Color(0xFF94A3B8),
                fontSize = 6.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${(vol * 100).toInt()}%",
                color = Pa5xNeonCyan,
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Black
            )
        }

        // Circular Rotary Fader
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(Pa5xKnurlHighlight, Pa5xKnurlSilver, Pa5xKnurlDark)
                    )
                )
                .border(1.dp, Color(0xFF1E293B), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        vol = (vol - dragAmount.y * 0.01f).coerceIn(0f, 1f)
                        onVolumeChange(vol)
                        change.consume()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            // Center indicator needle
            val angleRad = (vol * 270.0 - 135.0) * (PI / 180.0)
            Canvas(modifier = Modifier.size(20.dp)) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val nx = cx + (cos(angleRad) * (size.width * 0.4f)).toFloat()
                val ny = cy + (sin(angleRad) * (size.height * 0.4f)).toFloat()
                drawLine(
                    color = Pa5xRedDivider,
                    start = Offset(cx, cy),
                    end = Offset(nx, ny),
                    strokeWidth = 2.5f
                )
            }
        }
    }
}

/**
 * Authentic Korg Pa5X Right Control Deck:
 * - Iconic Data / Value Jog Wheel (Alpha Dial)
 * - 4 Matrix Performance Pads with live oriental percussion triggers
 */
@Composable
fun Pa5xRightControlPanel(
    bpm: Int,
    onAdjustBpm: (Int) -> Unit,
    onTriggerMatrixPad: (Int) -> Unit,
    hardwareTier: HardwareTier,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Pa5xChassisCard)
            .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(6.dp))
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Section: KORG Pa5X Data / Value Jog Wheel (Alpha Dial)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "DATA / VALUE",
                color = Color(0xFF94A3B8),
                fontSize = 7.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(2.dp))

            // The Iconic Circular Knurled Value Wheel
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .shadow(3.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Pa5xKnurlHighlight,
                                Pa5xKnurlSilver,
                                Color(0xFF475569),
                                Pa5xKnurlDark
                            )
                        )
                    )
                    .border(1.5.dp, Color(0xFF0F172A), CircleShape)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            if (dragAmount.y < -4f || dragAmount.x > 4f) {
                                onAdjustBpm(1)
                            } else if (dragAmount.y > 4f || dragAmount.x < -4f) {
                                onAdjustBpm(-1)
                            }
                            change.consume()
                        }
                    }
                    .testTag("pa5x_value_jog_wheel"),
                contentAlignment = Alignment.Center
            ) {
                // Concentric machining ridges
                Canvas(modifier = Modifier.size(46.dp)) {
                    drawCircle(
                        color = Color(0x33000000),
                        radius = size.width / 2f,
                        style = Stroke(width = 2f)
                    )
                    drawCircle(
                        color = Color(0x22FFFFFF),
                        radius = size.width * 0.35f,
                        style = Stroke(width = 1.5f)
                    )
                }

                // Finger dimple indentation (iconic Korg ergonomic cup)
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .offset(x = 12.dp, y = (-8).dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF334155))
                            )
                        )
                        .border(0.5.dp, Color(0xFF64748B), CircleShape)
                )

                // Center glowing cyan LED axis
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(Pa5xNeonCyan)
                        .shadow(2.dp, CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Step Buttons: - / + BPM
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(Pa5xButtonFace)
                        .border(0.5.dp, Pa5xButtonBevel, RoundedCornerShape(3.dp))
                        .clickable { onAdjustBpm(-1) }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .testTag("btn_bpm_minus"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Dec",
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }

                Text(
                    text = "$bpm",
                    color = Pa5xNeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(Pa5xButtonFace)
                        .border(0.5.dp, Pa5xButtonBevel, RoundedCornerShape(3.dp))
                        .clickable { onAdjustBpm(1) }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .testTag("btn_bpm_plus"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Inc",
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Divider
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color(0xFF334155))
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Bottom Section: 4 MATRIX PERFORMANCE PADS (Pa5X Signature Multi-Pads)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "MATRIX PADS",
                color = Color(0xFF94A3B8),
                fontSize = 6.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(2.dp))

            val padLabels = listOf("DUM", "TEK", "DAF", "CYM")
            val padColors = listOf(Pa5xNeonAmber, Pa5xNeonGreen, Pa5xNeonCyan, Pa5xMagenta)

            Column(
                verticalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Row 1: Pads 1 & 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    MatrixPadButton(
                        label = padLabels[0],
                        subtext = "PAD 1",
                        accentColor = padColors[0],
                        onTrigger = { onTriggerMatrixPad(0) },
                        modifier = Modifier.weight(1f)
                    )
                    MatrixPadButton(
                        label = padLabels[1],
                        subtext = "PAD 2",
                        accentColor = padColors[1],
                        onTrigger = { onTriggerMatrixPad(1) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: Pads 3 & 4
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    MatrixPadButton(
                        label = padLabels[2],
                        subtext = "PAD 3",
                        accentColor = padColors[2],
                        onTrigger = { onTriggerMatrixPad(2) },
                        modifier = Modifier.weight(1f)
                    )
                    MatrixPadButton(
                        label = padLabels[3],
                        subtext = "PAD 4",
                        accentColor = padColors[3],
                        onTrigger = { onTriggerMatrixPad(3) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

/**
 * Individual tactile rubber Matrix Pad with backlit LED frame
 */
@Composable
private fun MatrixPadButton(
    label: String,
    subtext: String,
    accentColor: Color,
    onTrigger: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val bgBrush = if (isPressed) {
        Brush.verticalGradient(listOf(accentColor, Color(0xFF1E293B)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF282834), Color(0xFF161620)))
    }

    Box(
        modifier = modifier
            .height(26.dp)
            .shadow(if (isPressed) 1.dp else 2.dp, RoundedCornerShape(3.dp))
            .clip(RoundedCornerShape(3.dp))
            .background(bgBrush)
            .border(
                1.dp,
                if (isPressed) accentColor else Color(0xFF383848),
                RoundedCornerShape(3.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                onTrigger()
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = label,
                color = if (isPressed) Color.White else Color(0xFFE2E8F0),
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = subtext,
                color = if (isPressed) Color.White else accentColor,
                fontSize = 5.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Authentic dark graphite Pa5X side cheek chassis border
 */
@Composable
fun Pa5xSideCheek(
    isLeft: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(6.dp)
            .background(
                Brush.horizontalGradient(
                    if (isLeft) listOf(Color(0xFF0D0D11), Color(0xFF202028), Color(0xFF101015))
                    else listOf(Color(0xFF101015), Color(0xFF202028), Color(0xFF0D0D11))
                )
            )
            .border(0.5.dp, Color(0xFF2E2E3A)),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hex chassis screws at top and bottom
        Box(
            modifier = Modifier
                .padding(vertical = 4.dp)
                .size(3.5.dp)
                .clip(CircleShape)
                .background(Color(0xFF475569))
                .border(0.5.dp, Color(0xFF1E293B), CircleShape)
        )

        Box(
            modifier = Modifier
                .padding(vertical = 4.dp)
                .size(3.5.dp)
                .clip(CircleShape)
                .background(Color(0xFF475569))
                .border(0.5.dp, Color(0xFF1E293B), CircleShape)
        )
    }
}
