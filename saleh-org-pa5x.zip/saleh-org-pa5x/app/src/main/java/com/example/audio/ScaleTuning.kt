package com.example.audio

enum class PersianDastgah(
    val titleEn: String,
    val titleFa: String,
    val description: String,
    // Microtonal offsets in cents for notes: C, C#, D, D#, E, F, F#, G, G#, A, A#, B
    // Index 0 = C, 1 = C#, 2 = D, 3 = D#, 4 = E, 5 = F, 6 = F#, 7 = G, 8 = G#, 9 = A, 10 = A#, 11 = B
    val centsOffsets: IntArray,
    // Set of allowed note degrees within octave (0..11) for Anti-Falsch pitch snapping
    val allowedDegrees: Set<Int>
) {
    SHOR(
        titleEn = "Dastgah Shor (E Koron)",
        titleFa = "Dastgah Shor",
        description = "The mother of Persian modes. Features E Koron (-50 cents) and B Koron.",
        centsOffsets = intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, -50, 0),
        allowedDegrees = setOf(0, 2, 4, 5, 7, 9, 10)
    ),
    CHAHARGAH(
        titleEn = "Dastgah Chahargah (D Koron & A Koron)",
        titleFa = "Dastgah Chahargah",
        description = "Heroic and energetic. Features D Koron and A Koron with augmented seconds.",
        centsOffsets = intArrayOf(0, 0, -50, 0, 0, 0, 0, 0, 0, -50, 0, 0),
        allowedDegrees = setOf(0, 2, 4, 5, 7, 9, 11)
    ),
    HOMAYOUN(
        titleEn = "Dastgah Homayoun (D Koron)",
        titleFa = "Dastgah Homayoun",
        description = "Majestic and emotional. Features D Koron with natural E and B flat.",
        centsOffsets = intArrayOf(0, 0, -50, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        allowedDegrees = setOf(0, 2, 4, 5, 7, 8, 10)
    ),
    ESFAHAN(
        titleEn = "Bayat-e Esfahan (E Koron)",
        titleFa = "Bayat-e Esfahan",
        description = "Deep, mystical, and nostalgic. Features E Koron and natural B.",
        centsOffsets = intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, 0, 0),
        allowedDegrees = setOf(0, 2, 4, 5, 7, 8, 11)
    ),
    SEGAH(
        titleEn = "Dastgah Segah (E Koron & B Koron)",
        titleFa = "Dastgah Segah",
        description = "Melancholic and profound. Third and seventh degrees are Koron.",
        centsOffsets = intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, -50, 0),
        allowedDegrees = setOf(0, 2, 4, 5, 7, 9, 10)
    ),
    STANDARD_WESTERN(
        titleEn = "Standard Equal Temperament",
        titleFa = "Standard Western",
        description = "Standard 12-TET tuning without microtonal quarter-tone adjustments.",
        centsOffsets = IntArray(12) { 0 },
        allowedDegrees = (0..11).toSet()
    );

    companion object {
        fun snapNoteIfAntiFalsch(note: Int, dastgah: PersianDastgah, isAntiFalschEnabled: Boolean): Int {
            if (!isAntiFalschEnabled || dastgah == STANDARD_WESTERN) return note
            val degree = ((note % 12) + 12) % 12
            if (degree in dastgah.allowedDegrees) return note
            
            // Find closest allowed degree
            val closest = dastgah.allowedDegrees.minByOrNull { allowed ->
                val diff = kotlin.math.abs(allowed - degree)
                kotlin.math.min(diff, 12 - diff)
            } ?: degree
            
            val diff = closest - degree
            return note + diff
        }
    }
}
