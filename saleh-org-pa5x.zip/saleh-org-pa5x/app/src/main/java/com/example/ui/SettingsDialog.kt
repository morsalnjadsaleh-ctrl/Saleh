package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.HardwareTier
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xChassisDark
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen

@Composable
fun SettingsDialog(
    currentTier: HardwareTier,
    rawKorgCount: Int,
    isRawKorgLocked: Boolean,
    onSelectTier: (HardwareTier) -> Unit,
    onOpenTelegram: () -> Unit,
    onOpenLayoutEditor: () -> Unit,
    onResetTrial: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Pa5xChassisDark)
                .border(1.dp, Pa5xNeonCyan, RoundedCornerShape(10.dp))
                .padding(14.dp)
                .testTag("settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PA5X HARDWARE & SYSTEM SETTINGS",
                        color = Pa5xNeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "v2.5 PROTOTYPE",
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // TELEGRAM VIP BANNER
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF0088CC), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SALEH VIP SETS & VIP SUPPORT",
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Get authentic proprietary encrypted sets (.saleh / .sp5x), custom styles, and Persian sound expansion packs directly from the official bot.",
                            color = Color(0xFFE2E8F0),
                            fontSize = 9.sp,
                            lineHeight = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onOpenTelegram,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0088CC),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(34.dp)
                                .testTag("settings_btn_telegram_shop")
                        ) {
                            Text(
                                text = "GET PREMIUM SETS VIA TELEGRAM",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 3-Tier Hardware Scaling Engine
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = Pa5xNeonAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "3-TIER HARDWARE SCALING (ANTI-LAG)",
                        color = Pa5xNeonAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                HardwareTier.values().forEach { tier ->
                    val isSelected = tier == currentTier
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isSelected) Pa5xMagenta.copy(alpha = 0.25f)
                                else Pa5xChassisCard
                            )
                            .border(
                                width = if (isSelected) 1.5.dp else 0.5.dp,
                                color = if (isSelected) Pa5xMagenta else Pa5xChassisBorder,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { onSelectTier(tier) }
                            .padding(8.dp)
                            .testTag("tier_${tier.name}")
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = tier.title,
                                    color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isSelected) {
                                    Text(
                                        text = "ACTIVE",
                                        color = Pa5xNeonGreen,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tier.description,
                                color = Color(0xFF94A3B8),
                                fontSize = 8.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // SET TRIAL STATUS & RESET
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RAW KORG .SET TRIAL: $rawKorgCount / 2 USED",
                                color = if (isRawKorgLocked) Color(0xFFEF4444) else Pa5xNeonAmber,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isRawKorgLocked) "Status: LOCKED (Buy Encrypted)" else "Status: TRIAL ACTIVE",
                                color = Color(0xFF94A3B8),
                                fontSize = 8.sp
                            )
                        }
                        OutlinedButton(
                            onClick = onResetTrial,
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text(text = "Reset 0/2", fontSize = 8.5.sp, color = Color(0xFFCBD5E1))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Shortcuts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onDismiss()
                            onOpenLayoutEditor()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Pa5xChassisCard, contentColor = Color.White),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    ) {
                        Text(text = "Open Layout Editor", fontSize = 9.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Pa5xMagenta, contentColor = Color.White),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    ) {
                        Text(text = "Close Settings", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
