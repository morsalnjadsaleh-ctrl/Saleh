package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SetFileType
import com.example.model.SetPackage
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xMonitorBg
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen

@Composable
fun SetLoaderPane(
    rawKorgCount: Int,
    isRawKorgLocked: Boolean,
    currentLoadedSetName: String,
    onLoadRawKorgSet: (SetPackage) -> Unit,
    onLoadEncryptedSet: (SetPackage) -> Unit,
    onOpenTelegram: () -> Unit,
    onResetTrial: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sampleSets = remember {
        listOf(
            SetPackage(
                id = "set_saleh_vip",
                name = "Saleh Oriental Pa5X VIP Edition",
                fileName = "Saleh_Pa5X_VIP.saleh",
                fileType = SetFileType.SALEH_ENCRYPTED,
                description = "Proprietary high-definition Persian & Oriental Pa5X multisamples with zero latency.",
                author = "Saleh Sound Labs",
                styleCount = 128,
                soundCount = 340,
                padCount = 96,
                fileSizeMb = 480.0,
                isEncrypted = true
            ),
            SetPackage(
                id = "set_sp5x_shor",
                name = "Persian Dastgah 6/8 & Band",
                fileName = "Persian_Shor_Band.sp5x",
                fileType = SetFileType.SALEH_ENCRYPTED,
                description = "Authentic Daf, Tombak, Santur, Kamancheh and modern pop-oriental rhythms.",
                author = "Saleh Master Arranger",
                styleCount = 96,
                soundCount = 210,
                padCount = 64,
                fileSizeMb = 320.0,
                isEncrypted = true
            ),
            SetPackage(
                id = "set_korg_raw_1",
                name = "Korg Pa4X Classic Converted Set",
                fileName = "USER01.SET",
                fileType = SetFileType.RAW_KORG_SET,
                description = "Raw legacy Korg .SET files. (Restricted to 2 Free Trial loads).",
                author = "Legacy Korg Community",
                styleCount = 48,
                soundCount = 110,
                padCount = 32,
                fileSizeMb = 145.0,
                isEncrypted = false
            ),
            SetPackage(
                id = "set_korg_raw_2",
                name = "Arabic Halay & Baladi Set",
                fileName = "ARABIC_2026.SET",
                fileType = SetFileType.RAW_KORG_SET,
                description = "Raw Korg format style rhythm pack. (Restricted to 2 Free Trial loads).",
                author = "Open Arranger Group",
                styleCount = 52,
                soundCount = 85,
                padCount = 24,
                fileSizeMb = 160.0,
                isEncrypted = false
            ),
            SetPackage(
                id = "set_turkish_saleh",
                name = "Turkish Roman & Ciftetelli VIP",
                fileName = "Turkish_VIP_Arranger.saleh",
                fileType = SetFileType.SALEH_ENCRYPTED,
                description = "Ultra high-energy Turkish rhythms and clarinets in proprietary Saleh format.",
                author = "Saleh Sound Labs",
                styleCount = 84,
                soundCount = 190,
                padCount = 48,
                fileSizeMb = 295.0,
                isEncrypted = true
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Pa5xMonitorBg)
            .padding(6.dp)
            .testTag("set_loader_pane")
    ) {
        // Status row showing Trial Counter and Telegram CTA
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            if (isRawKorgLocked) Color(0xFF450A0A) else Color(0xFF1E293B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = if (isRawKorgLocked) Color(0xFFEF4444) else Pa5xNeonCyan,
                    shape = RoundedCornerShape(6.dp)
                )
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isRawKorgLocked) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RAW KORG .SET TRIAL: 2/2 REACHED (LOCKED)",
                            color = Color(0xFFEF4444),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    } else {
                        Text(
                            text = "RAW KORG .SET TRIAL: $rawKorgCount / 2 LOADS USED",
                            color = Pa5xNeonAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "PROPRIETARY FORMATS (.saleh / .sp5x): UNLIMITED ACCESS",
                    color = Pa5xNeonGreen,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Direct Telegram Shop button
            Button(
                onClick = onOpenTelegram,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0088CC), // Official Telegram Blue
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(4.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("btn_telegram_shop")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = null,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "GET PREMIUM SETS VIA TELEGRAM",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Set list
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(sampleSets) { pkg ->
                val isCurrentlyLoaded = pkg.name == currentLoadedSetName
                val isRaw = pkg.fileType == SetFileType.RAW_KORG_SET
                val isLocked = isRaw && isRawKorgLocked

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (isCurrentlyLoaded) Pa5xMagenta.copy(alpha = 0.2f)
                            else Pa5xChassisCard
                        )
                        .border(
                            width = if (isCurrentlyLoaded) 1.5.dp else 0.5.dp,
                            color = when {
                                isCurrentlyLoaded -> Pa5xMagenta
                                isLocked -> Color(0xFF7F1D1D)
                                else -> Pa5xChassisBorder
                            },
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = pkg.name,
                                color = if (isLocked) Color(0xFF94A3B8) else Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Badge
                            if (pkg.isEncrypted) {
                                Box(
                                    modifier = Modifier
                                        .background(Pa5xNeonGreen.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "VIP ENCRYPTED (.saleh)",
                                        color = Pa5xNeonGreen,
                                        fontSize = 7.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isLocked) Color(0xFF7F1D1D) else Color(0xFF78350F),
                                            RoundedCornerShape(2.dp)
                                        )
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = if (isLocked) "RAW .SET (LOCKED)" else "RAW .SET (TRIAL 2-MAX)",
                                        color = if (isLocked) Color(0xFFFCA5A5) else Pa5xNeonAmber,
                                        fontSize = 7.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${pkg.fileName} • ${pkg.fileSizeMb}MB • ${pkg.styleCount} Styles • ${pkg.soundCount} Sounds",
                            color = Color(0xFF94A3B8),
                            fontSize = 8.sp
                        )
                    }

                    // Load Action Button
                    Button(
                        onClick = {
                            if (isRaw) onLoadRawKorgSet(pkg)
                            else onLoadEncryptedSet(pkg)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when {
                                isLocked -> Color(0xFF475569)
                                pkg.isEncrypted -> Pa5xNeonGreen
                                else -> Pa5xNeonAmber
                            },
                            contentColor = if (pkg.isEncrypted) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(3.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(24.dp)
                            .testTag("btn_load_${pkg.id}")
                    ) {
                        Text(
                            text = when {
                                isCurrentlyLoaded -> "LOADED"
                                isLocked -> "LOCKED"
                                else -> "LOAD SET"
                            },
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
