package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ArrangerTrackState
import com.example.model.HardwareTier
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xMonitorBg
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen

@Composable
fun TrackMixerPane(
    tracks: List<ArrangerTrackState>,
    vuLevels: FloatArray,
    hardwareTier: HardwareTier,
    onVolumeChange: (index: Int, volume: Float) -> Unit,
    onToggleMute: (index: Int) -> Unit,
    onToggleSolo: (index: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Pa5xMonitorBg)
            .padding(4.dp)
            .testTag("track_mixer_pane")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Pa5xChassisCard, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "KORG Pa5X 8-TRACK ARRANGER CONSOLE",
                color = Pa5xNeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "HIERARCHY: DRUM (CH 10) • PERC • BASS • ACC1-5",
                color = Color(0xFF94A3B8),
                fontSize = 9.sp
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            tracks.forEachIndexed { index, track ->
                val vu = if (index < vuLevels.size) vuLevels[index] else 0f
                TrackChannelStrip(
                    index = index,
                    track = track,
                    vuLevel = vu,
                    hardwareTier = hardwareTier,
                    onVolumeChange = { vol -> onVolumeChange(index, vol) },
                    onToggleMute = { onToggleMute(index) },
                    onToggleSolo = { onToggleSolo(index) },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
            }
        }
    }
}

@Composable
private fun TrackChannelStrip(
    index: Int,
    track: ArrangerTrackState,
    vuLevel: Float,
    hardwareTier: HardwareTier,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleSolo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF0F172A))
            .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Track Header with distinct Pa5X colors
        val headerColor = when (index) {
            0 -> Color(0xFFEF4444) // Drum Ch 10 Red
            1 -> Color(0xFFF97316) // Perc Orange
            2 -> Color(0xFF3B82F6) // Bass Blue
            3 -> Color(0xFF10B981) // ACC1 Green
            4 -> Color(0xFF8B5CF6) // ACC2 Purple
            5 -> Color(0xFF06B6D4) // ACC3 Cyan
            6 -> Color(0xFFEC4899) // ACC4 Pink
            else -> Color(0xFFF59E0B) // ACC5 Amber
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerColor, RoundedCornerShape(2.dp))
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "TR ${index + 1}",
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.Black
            )
        }

        Text(
            text = track.name,
            color = Color.White,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 1.dp)
        )

        // VU Meter + Fader in a Row
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // LED VU Meter (10 vertical segments)
            LedVuMeter(
                level = vuLevel,
                enableAnimations = hardwareTier.enableAnimations,
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
            )

            Spacer(modifier = Modifier.width(2.dp))

            // Volume Fader
            Column(
                modifier = Modifier.fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Slider rotated or custom vertical fader
                VerticalFader(
                    value = track.volume,
                    onValueChange = onVolumeChange,
                    modifier = Modifier
                        .width(18.dp)
                        .weight(1f)
                )
            }
        }

        // Mute / Solo Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Mute Button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(18.dp)
                    .padding(horizontal = 1.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (track.isMuted) Color(0xFFDC2626) else Color(0xFF334155))
                    .clickable { onToggleMute() }
                    .testTag("mute_tr_${index + 1}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "M",
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Solo Button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(18.dp)
                    .padding(horizontal = 1.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (track.isSolo) Pa5xNeonAmber else Color(0xFF334155))
                    .clickable { onToggleSolo() }
                    .testTag("solo_tr_${index + 1}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "S",
                    color = if (track.isSolo) Color.Black else Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun LedVuMeter(
    level: Float,
    enableAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    val totalSegments = 10
    val activeSegments = (level * totalSegments).toInt().coerceIn(0, totalSegments)

    Column(
        modifier = modifier
            .background(Color.Black, RoundedCornerShape(2.dp))
            .padding(1.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp, Alignment.Bottom)
    ) {
        for (i in (totalSegments - 1) downTo 0) {
            val isActive = i < activeSegments
            val segColor = when {
                i >= 8 -> if (isActive) Color(0xFFEF4444) else Color(0xFF450A0A) // Red peak
                i >= 5 -> if (isActive) Color(0xFFFBBF24) else Color(0xFF451A03) // Amber
                else -> if (isActive) Color(0xFF22C55E) else Color(0xFF052E16) // Green
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(segColor, RoundedCornerShape(1.dp))
            )
        }
    }
}

@Composable
private fun VerticalFader(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Custom touch-friendly vertical fader
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF020617))
            .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(2.dp))
    ) {
        // Track centerline
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .align(Alignment.Center)
                .background(Color(0xFF475569))
        )

        // Handle
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(value.coerceIn(0.05f, 1f))
                .align(Alignment.BottomCenter)
                .background(Pa5xMagenta.copy(alpha = 0.35f))
        )

        // Thumb bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .align(Alignment.TopCenter)
                .padding(top = ((1f - value) * 45).dp) // approximate visual offset
                .clip(RoundedCornerShape(1.dp))
                .background(Color.White)
        )
    }
}
