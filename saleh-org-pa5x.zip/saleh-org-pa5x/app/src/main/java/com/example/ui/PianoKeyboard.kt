package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PersianDastgah
import com.example.model.HardwareTier
import com.example.ui.theme.Pa5xBlackKey
import com.example.ui.theme.Pa5xBlackKeyPressed
import com.example.ui.theme.Pa5xChassisDark
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen
import com.example.ui.theme.Pa5xRedFelt
import com.example.ui.theme.Pa5xRedFeltShadow
import com.example.ui.theme.Pa5xWhiteKey
import com.example.ui.theme.Pa5xWhiteKeyPressed

data class KeyInfo(
    val midiNote: Int,
    val isBlack: Boolean,
    val englishLabel: String,
    val persianLabel: String,
    val whiteKeyIndex: Int // Index among white keys (for positioning)
)

@Composable
fun PianoKeyboard(
    octaveShift: Int,
    pressedNotes: Set<Int>,
    currentDastgah: PersianDastgah,
    isAntiFalschEnabled: Boolean,
    hardwareTier: HardwareTier,
    showPersianLabels: Boolean,
    showEnglishLabels: Boolean,
    onKeyDown: (pointerId: Int, midiNote: Int) -> Unit,
    onKeyUp: (pointerId: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // Generate 2 octaves + top C (15 white keys, 10 black keys)
    // Base root note (C3 = 48 + octaveShift * 12)
    val baseMidiNote = (48 + octaveShift * 12).coerceIn(24, 84)

    val englishNames = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val persianNames = listOf("Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si")
    val isBlackPattern = listOf(false, true, false, true, false, false, true, false, true, false, true, false)

    // Build list of keys for 2 octaves (24 notes) + final C (1 note)
    val whiteKeys = remember(baseMidiNote) {
        val list = mutableListOf<KeyInfo>()
        var whiteIdx = 0
        for (i in 0..24) {
            val midi = baseMidiNote + i
            val semitone = (midi % 12 + 12) % 12
            val isBlack = isBlackPattern[semitone]
            if (!isBlack) {
                list.add(
                    KeyInfo(
                        midiNote = midi,
                        isBlack = false,
                        englishLabel = englishNames[semitone],
                        persianLabel = persianNames[semitone],
                        whiteKeyIndex = whiteIdx++
                    )
                )
            }
        }
        list
    }

    val blackKeys = remember(baseMidiNote) {
        val list = mutableListOf<KeyInfo>()
        var whiteCountSoFar = 0
        for (i in 0..24) {
            val midi = baseMidiNote + i
            val semitone = (midi % 12 + 12) % 12
            val isBlack = isBlackPattern[semitone]
            if (!isBlack) {
                whiteCountSoFar++
            } else {
                list.add(
                    KeyInfo(
                        midiNote = midi,
                        isBlack = true,
                        englishLabel = englishNames[semitone],
                        persianLabel = persianNames[semitone],
                        whiteKeyIndex = whiteCountSoFar - 1
                    )
                )
            }
        }
        list
    }

    val totalWhiteKeys = whiteKeys.size // 15 white keys

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .background(Pa5xChassisDark)
            .testTag("piano_keyboard_box")
    ) {
        val totalWidthPx = constraints.maxWidth.toFloat()
        val totalHeightPx = constraints.maxHeight.toFloat()
        val whiteKeyWidthPx = totalWidthPx / totalWhiteKeys
        val blackKeyWidthPx = whiteKeyWidthPx * 0.62f
        val blackKeyHeightPx = totalHeightPx * 0.62f

        // Multi-touch detector using pointer events
        val pointerActiveKeys = remember { mutableMapOf<PointerId, Int>() }

        Column(modifier = Modifier.fillMaxSize()) {
            // Authentic Korg Pa5X Keybed Red Velvet Damper Felt Strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Pa5xRedFeltShadow, Pa5xRedFelt, Pa5xRedFeltShadow)
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(baseMidiNote, isAntiFalschEnabled, currentDastgah) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val pointerId = down.id

                        fun findKeyAt(x: Float, y: Float): Int? {
                            // Check black keys first (they sit on top)
                            if (y <= blackKeyHeightPx) {
                                for (bk in blackKeys) {
                                    val left = (bk.whiteKeyIndex + 1) * whiteKeyWidthPx - (blackKeyWidthPx / 2f)
                                    val right = left + blackKeyWidthPx
                                    if (x in left..right) {
                                        return bk.midiNote
                                    }
                                }
                            }
                            // Check white keys
                            val whiteIdx = (x / whiteKeyWidthPx).toInt().coerceIn(0, totalWhiteKeys - 1)
                            return whiteKeys.getOrNull(whiteIdx)?.midiNote
                        }

                        val initialNote = findKeyAt(down.position.x, down.position.y)
                        if (initialNote != null) {
                            pointerActiveKeys[pointerId] = initialNote
                            onKeyDown(pointerId.value.toInt(), initialNote)
                        }

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == pointerId }
                            if (change == null || !change.pressed) {
                                pointerActiveKeys.remove(pointerId)?.let {
                                    onKeyUp(pointerId.value.toInt())
                                }
                                break
                            } else {
                                val currentNote = findKeyAt(change.position.x, change.position.y)
                                val previousNote = pointerActiveKeys[pointerId]
                                if (currentNote != null && currentNote != previousNote) {
                                    onKeyUp(pointerId.value.toInt())
                                    pointerActiveKeys[pointerId] = currentNote
                                    onKeyDown(pointerId.value.toInt(), currentNote)
                                }
                                change.consume()
                            }
                        }
                    }
                }
        ) {
            // Render White Keys
            Row(modifier = Modifier.fillMaxSize()) {
                whiteKeys.forEach { key ->
                    val isPressed = pressedNotes.contains(key.midiNote)
                    val noteDegree = ((key.midiNote % 12) + 12) % 12
                    val isKoron = currentDastgah.centsOffsets[noteDegree] == -50
                    val isAllowedDegree = noteDegree in currentDastgah.allowedDegrees

                    WhiteKeyView(
                        key = key,
                        isPressed = isPressed,
                        isKoron = isKoron,
                        isOffScale = isAntiFalschEnabled && !isAllowedDegree,
                        hardwareTier = hardwareTier,
                        showPersian = showPersianLabels,
                        showEnglish = showEnglishLabels,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    )
                }
            }

            // Render Black Keys (positioned on top)
            blackKeys.forEach { key ->
                val isPressed = pressedNotes.contains(key.midiNote)
                val noteDegree = ((key.midiNote % 12) + 12) % 12
                val isKoron = currentDastgah.centsOffsets[noteDegree] == -50
                val isAllowedDegree = noteDegree in currentDastgah.allowedDegrees

                val leftOffsetDp = with(androidx.compose.ui.platform.LocalDensity.current) {
                    ((key.whiteKeyIndex + 1) * whiteKeyWidthPx - (blackKeyWidthPx / 2f)).toDp()
                }
                val widthDp = with(androidx.compose.ui.platform.LocalDensity.current) { blackKeyWidthPx.toDp() }
                val heightDp = with(androidx.compose.ui.platform.LocalDensity.current) { blackKeyHeightPx.toDp() }

                BlackKeyView(
                    key = key,
                    isPressed = isPressed,
                    isKoron = isKoron,
                    isOffScale = isAntiFalschEnabled && !isAllowedDegree,
                    hardwareTier = hardwareTier,
                    showPersian = showPersianLabels,
                    showEnglish = showEnglishLabels,
                    modifier = Modifier
                        .offset(x = leftOffsetDp, y = 0.dp)
                        .width(widthDp)
                        .height(heightDp)
                )
            }
        }
    }
}
}

@Composable
private fun WhiteKeyView(
    key: KeyInfo,
    isPressed: Boolean,
    isKoron: Boolean,
    isOffScale: Boolean,
    hardwareTier: HardwareTier,
    showPersian: Boolean,
    showEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    val bgBrush = when {
        isPressed -> Brush.verticalGradient(listOf(Pa5xWhiteKeyPressed, Color(0xFF94A3B8), Color(0xFF64748B)))
        isKoron -> Brush.verticalGradient(listOf(Color(0xFFF0FDF4), Color(0xFFDCFCE7), Color(0xFFBBF7D0)))
        hardwareTier.enable3dEffects -> Brush.verticalGradient(
            listOf(Color.White, Color(0xFFFAFAFA), Pa5xWhiteKey, Color(0xFFE2E8F0))
        )
        else -> Brush.verticalGradient(listOf(Pa5xWhiteKey, Pa5xWhiteKey))
    }

    val shadowElevation = if (hardwareTier.enable3dEffects && !isPressed) 4.dp else 0.5.dp

    Box(
        modifier = modifier
            .padding(horizontal = 0.75.dp)
            .offset(y = if (isPressed) 2.dp else 0.dp)
            .shadow(shadowElevation, RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
            .clip(RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp))
            .background(bgBrush)
            .border(
                width = if (isKoron) 1.5.dp else 0.5.dp,
                color = if (isKoron) Pa5xNeonGreen else Color(0xFFCBD5E1),
                shape = RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp)
            )
            .testTag("white_key_${key.midiNote}")
    ) {
        // Bottom lip glossy bevel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .align(Alignment.BottomCenter)
                .background(
                    if (isPressed) Color(0xFF64748B) else Color(0xFFD1D5DB)
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isKoron) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFFDCFCE7))
                        .padding(horizontal = 3.dp, vertical = 0.5.dp)
                ) {
                    Text(
                        text = "KORON",
                        color = Color(0xFF15803D),
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
            if (showEnglish) {
                Text(
                    text = key.englishLabel,
                    color = if (isOffScale) Color(0xFF94A3B8) else Color(0xFF1E293B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if (showPersian) {
                Text(
                    text = key.persianLabel,
                    color = if (isOffScale) Color(0xFF94A3B8) else Color(0xFF475569),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun BlackKeyView(
    key: KeyInfo,
    isPressed: Boolean,
    isKoron: Boolean,
    isOffScale: Boolean,
    hardwareTier: HardwareTier,
    showPersian: Boolean,
    showEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    val bgBrush = when {
        isPressed -> Brush.verticalGradient(listOf(Pa5xNeonCyan, Color(0xFF0284C7), Pa5xBlackKeyPressed))
        isKoron -> Brush.verticalGradient(listOf(Color(0xFF065F46), Color(0xFF047857), Pa5xBlackKey))
        hardwareTier.enable3dEffects -> Brush.verticalGradient(
            listOf(Color(0xFF3F3F4E), Color(0xFF26262E), Pa5xBlackKey, Color(0xFF09090B))
        )
        else -> Brush.verticalGradient(listOf(Pa5xBlackKey, Pa5xBlackKey))
    }

    val shadowElevation = if (hardwareTier.enable3dEffects && !isPressed) 6.dp else 1.dp

    Box(
        modifier = modifier
            .offset(y = if (isPressed) 2.5.dp else 0.dp)
            .shadow(shadowElevation, RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
            .clip(RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
            .background(bgBrush)
            .border(
                width = if (isKoron) 1.5.dp else 0.5.dp,
                color = if (isKoron) Pa5xNeonGreen else Color(0xFF27272A),
                shape = RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp)
            )
            .testTag("black_key_${key.midiNote}")
    ) {
        // Top surface inner matte highlight
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x33FFFFFF), Color.Transparent)
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isKoron) {
                Text(
                    text = "p", // Koron symbol
                    color = Pa5xNeonGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }
            if (showEnglish) {
                Text(
                    text = key.englishLabel,
                    color = if (isOffScale) Color(0xFF71717A) else Color(0xFFE4E4E7),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (showPersian) {
                Text(
                    text = key.persianLabel,
                    color = if (isOffScale) Color(0xFF52525B) else Color(0xFFA1A1AA),
                    fontSize = 7.5.sp
                )
            }
        }
    }
}
