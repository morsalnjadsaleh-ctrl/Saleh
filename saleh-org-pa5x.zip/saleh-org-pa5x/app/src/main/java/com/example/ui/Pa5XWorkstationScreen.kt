package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ArrangerVariation
import com.example.model.HardwareTier
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisBrushed
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xChassisDark
import com.example.ui.theme.Pa5xCyanGlow
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xMagentaDark
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen
import com.example.ui.theme.Pa5xRedDivider
import com.example.ui.theme.Pa5xRedGlow

@Composable
fun Pa5XWorkstationScreen(
    viewModel: Pa5XViewModel,
    modifier: Modifier = Modifier
) {
    val hardwareTier by viewModel.hardwareTier.collectAsState()
    val layoutConfig by viewModel.layoutConfig.collectAsState()
    val currentDastgah by viewModel.currentDastgah.collectAsState()
    val isAntiFalschEnabled by viewModel.isAntiFalschEnabled.collectAsState()

    val rawKorgCount by viewModel.rawKorgSetCount.collectAsState()
    val isRawKorgLocked by viewModel.isRawKorgSetLocked.collectAsState()
    val currentLoadedSetName by viewModel.currentLoadedSetName.collectAsState()
    val showTrialLimitDialog by viewModel.showTrialLimitDialog.collectAsState()

    val isOtgDocked by viewModel.isOtgDocked.collectAsState()
    val octaveShift by viewModel.octaveShift.collectAsState()
    val pressedNotes by viewModel.pressedNotes.collectAsState()

    val isArrangerPlaying by viewModel.isArrangerPlaying.collectAsState()
    val isSynchroStart by viewModel.isSynchroStart.collectAsState()
    val currentVariation by viewModel.currentVariation.collectAsState()
    val bpm by viewModel.bpm.collectAsState()
    val currentStep by viewModel.currentStep.collectAsState()
    val currentBeat by viewModel.currentBeat.collectAsState()
    val trackVus by viewModel.trackVuLevels.collectAsState()
    val trackStates by viewModel.trackStates.collectAsState()
    val aiComplexity by viewModel.aiComplexity.collectAsState()
    val aiHumanize by viewModel.aiHumanize.collectAsState()

    val showSettingsDialog by viewModel.showSettingsDialog.collectAsState()
    val showLayoutEditorDialog by viewModel.showLayoutEditorDialog.collectAsState()

    // Chassis background brush based on hardware tier
    val chassisBgBrush = when {
        hardwareTier.enable3dEffects -> Brush.verticalGradient(
            listOf(
                Color(0xFF261828), // Brushed Magenta tint
                Pa5xChassisDark,
                Color(0xFF181520),
                Pa5xChassisDark
            )
        )
        hardwareTier == HardwareTier.TIER_2 -> Brush.verticalGradient(
            listOf(Color(0xFF1E1724), Pa5xChassisDark, Color(0xFF131018))
        )
        else -> Brush.verticalGradient(listOf(Pa5xChassisDark, Pa5xChassisDark)) // Flat 2D for Tier 3
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(chassisBgBrush)
            .testTag("pa5x_workstation_chassis")
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Left End Cheek (Anodized Workstation Metal)
            Pa5xSideCheek(isLeft = true)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                // TOP WORKSTATION CHASSIS BAR
                TopHardwareHeader(
                    currentTier = hardwareTier,
                    isOtgDocked = isOtgDocked,
                    onVolumeChange = { viewModel.setMasterVolume(it) },
                    onToggleOtg = { viewModel.toggleOtgDocking() },
                    onOpenLayoutEditor = { viewModel.showLayoutEditorDialog.value = true },
                    onOpenSettings = { viewModel.showSettingsDialog.value = true }
                )

                // MAIN WORKSTATION WORKSPACE (Monitor + Hardware Control Panels)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Left Hardware Strip: Pitch Bend & Mod Wheels (if visible)
                    if (layoutConfig.showPitchBendMod && !isOtgDocked) {
                        PitchBendModWheels(
                            modifier = Modifier
                                .width(52.dp)
                                .fillMaxHeight()
                        )
                    }

                    // Center Column: Scaled Touchscreen Arranger Monitor + Variation 1-4 Bar
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Central Touchscreen Monitor
                        ArrangerMonitor(
                            currentLoadedSetName = currentLoadedSetName,
                            rawKorgCount = rawKorgCount,
                            isRawKorgLocked = isRawKorgLocked,
                            hardwareTier = hardwareTier,
                            currentDastgah = currentDastgah,
                            isAntiFalschEnabled = isAntiFalschEnabled,
                            isArrangerPlaying = isArrangerPlaying,
                            isSynchroStart = isSynchroStart,
                            currentVariation = currentVariation,
                            bpm = bpm,
                            currentStep = currentStep,
                            currentBeat = currentBeat,
                            trackStates = trackStates,
                            trackVus = trackVus,
                            aiComplexity = aiComplexity,
                            aiHumanize = aiHumanize,
                            onTrackVolumeChange = { idx, vol -> viewModel.setTrackVolume(idx, vol) },
                            onTrackToggleMute = { idx -> viewModel.toggleTrackMute(idx) },
                            onTrackToggleSolo = { idx -> viewModel.toggleTrackSolo(idx) },
                            onDastgahSelect = { dastgah -> viewModel.setDastgah(dastgah) },
                            onToggleAntiFalsch = { viewModel.toggleAntiFalsch() },
                            onAiComplexityChange = { c -> viewModel.setAiComplexity(c) },
                            onAiHumanizeChange = { h -> viewModel.setAiHumanize(h) },
                            onAiAutoConfig = { viewModel.autoConfigAiDrummer() },
                            onLoadRawKorgSet = { pkg -> viewModel.loadRawKorgSet(pkg) },
                            onLoadEncryptedSet = { pkg -> viewModel.loadSalehEncryptedSet(pkg) },
                            onOpenTelegram = { viewModel.openTelegramShop() },
                            onResetTrial = { viewModel.resetTrialForTesting() },
                            onBpmChange = { newBpm -> viewModel.setBpm(newBpm) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )

                        // Hardware Arranger Control Bar: START/STOP, SYNCHRO, VARIATION 1-4
                        if (layoutConfig.showVariationBar) {
                            HardwareArrangerBar(
                                isPlaying = isArrangerPlaying,
                                isSynchroStart = isSynchroStart,
                                currentVariation = currentVariation,
                                currentBeat = currentBeat,
                                octaveShift = octaveShift,
                                showOctaves = layoutConfig.showOctaveControls,
                                onToggleStartStop = { viewModel.toggleArrangerStartStop() },
                                onToggleSynchro = { viewModel.toggleSynchroStart() },
                                onSelectVariation = { variation -> viewModel.setVariation(variation) },
                                onTriggerFill = { viewModel.triggerMatrixPad(3) },
                                onOctaveShift = { delta -> viewModel.shiftOctave(delta) }
                            )
                        }
                    }

                    // Right Hardware Deck: Iconic Korg Pa5X Alpha Jog Dial & 4 Matrix Performance Pads
                    if (!isOtgDocked) {
                        Pa5xRightControlPanel(
                            bpm = bpm,
                            onAdjustBpm = { delta -> viewModel.adjustBpm(delta) },
                            onTriggerMatrixPad = { padIdx -> viewModel.triggerMatrixPad(padIdx) },
                            hardwareTier = hardwareTier,
                            modifier = Modifier
                                .width(86.dp)
                                .fillMaxHeight()
                        )
                    }
                }

                // ICONIC PA5X RED DIVIDER LINE
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(
                            if (hardwareTier.enable3dEffects) {
                                Brush.verticalGradient(listOf(Pa5xRedGlow, Pa5xRedDivider, Color(0xFFB71C1C)))
                            } else {
                                Brush.verticalGradient(listOf(Pa5xRedDivider, Pa5xRedDivider))
                            }
                        )
                )

                // PIANO KEYBOARD SECTION (Fades out when OTG Auto-Docking is active)
                AnimatedVisibility(
                    visible = !isOtgDocked,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    PianoKeyboard(
                        octaveShift = octaveShift,
                        pressedNotes = pressedNotes,
                        currentDastgah = currentDastgah,
                        isAntiFalschEnabled = isAntiFalschEnabled,
                        hardwareTier = hardwareTier,
                        showPersianLabels = layoutConfig.showPersianKeyLabels,
                        showEnglishLabels = layoutConfig.showEnglishKeyLabels,
                        onKeyDown = { pointerId, note -> viewModel.onKeyDown(pointerId, note) },
                        onKeyUp = { pointerId -> viewModel.onKeyUp(pointerId) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(
                                (layoutConfig.keyboardHeightRatio * 520).coerceIn(160f, 260f).dp
                            )
                    )
                }

                // In OTG Docked mode, display an expanded dock status banner
                if (isOtgDocked) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0B1120))
                            .border(1.dp, Pa5xNeonCyan, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cable,
                                contentDescription = "OTG Docked",
                                tint = Pa5xNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "USB/OTG MIDI HARDWARE DOCKED • EXPANDED LIVE ARRANGER MODE",
                                color = Pa5xNeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Pa5xMagenta)
                                    .clickable { viewModel.toggleOtgDocking() }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Restore Virtual Keys",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Right End Cheek (Anodized Workstation Metal)
            Pa5xSideCheek(isLeft = false)
        }

        // Dialog Overlays
        if (showSettingsDialog) {
            SettingsDialog(
                currentTier = hardwareTier,
                rawKorgCount = rawKorgCount,
                isRawKorgLocked = isRawKorgLocked,
                onSelectTier = { tier -> viewModel.setHardwareTier(tier) },
                onOpenTelegram = { viewModel.openTelegramShop() },
                onOpenLayoutEditor = { viewModel.showLayoutEditorDialog.value = true },
                onResetTrial = { viewModel.resetTrialForTesting() },
                onDismiss = { viewModel.showSettingsDialog.value = false }
            )
        }

        if (showLayoutEditorDialog) {
            LayoutEditorDialog(
                initialConfig = layoutConfig,
                onSaveConfig = { newConfig -> viewModel.updateLayoutConfig(newConfig) },
                onResetFactory = { viewModel.resetLayoutToFactory() },
                onDismiss = { viewModel.showLayoutEditorDialog.value = false }
            )
        }

        if (showTrialLimitDialog) {
            TrialLimitDialog(
                onDismiss = { viewModel.dismissTrialLimitDialog() },
                onOpenTelegram = {
                    viewModel.dismissTrialLimitDialog()
                    viewModel.openTelegramShop()
                }
            )
        }
    }
}

@Composable
private fun TopHardwareHeader(
    currentTier: HardwareTier,
    isOtgDocked: Boolean,
    onVolumeChange: (Float) -> Unit,
    onToggleOtg: () -> Unit,
    onOpenLayoutEditor: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Pa5xChassisBrushed)
            .border(0.5.dp, Pa5xChassisBorder)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Official KORG Pa5X Physical Badge
        KorgPa5xLogoBadge()

        // Action Buttons: Master Volume, OTG Dock, Layout Editor, Physical SETTINGS button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Master Volume Rotary Knob with dB scale
            Pa5xMasterVolumeDial(
                volume = 0.85f,
                onVolumeChange = onVolumeChange
            )

            // OTG Auto-Docking Toggle
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isOtgDocked) Pa5xNeonCyan else Pa5xChassisCard)
                    .border(0.5.dp, if (isOtgDocked) Pa5xNeonCyan else Pa5xChassisBorder, RoundedCornerShape(4.dp))
                    .clickable { onToggleOtg() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("btn_otg_dock"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Cable,
                        contentDescription = "OTG",
                        tint = if (isOtgDocked) Color.Black else Pa5xNeonCyan,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isOtgDocked) "OTG DOCKED" else "USB DOCK",
                        color = if (isOtgDocked) Color.Black else Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Layout Customization Mode Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Pa5xChassisCard)
                    .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
                    .clickable { onOpenLayoutEditor() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("btn_layout_editor"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DashboardCustomize,
                        contentDescription = "Layout",
                        tint = Pa5xNeonAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LAYOUT",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Dedicated physical "SETTINGS" button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Pa5xMagentaDark)
                    .border(1.dp, Pa5xMagenta, RoundedCornerShape(4.dp))
                    .clickable { onOpenSettings() }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("btn_physical_settings"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SETTINGS",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun HardwareArrangerBar(
    isPlaying: Boolean,
    isSynchroStart: Boolean,
    currentVariation: ArrangerVariation,
    currentBeat: Int,
    octaveShift: Int,
    showOctaves: Boolean,
    onToggleStartStop: () -> Unit,
    onToggleSynchro: () -> Unit,
    onSelectVariation: (ArrangerVariation) -> Unit,
    onTriggerFill: () -> Unit,
    onOctaveShift: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Pa5xChassisCard)
            .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Arranger Engine Hardware Transport Buttons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // START/STOP Button (Iconic glowing workstation toggle)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (isPlaying) Brush.verticalGradient(listOf(Color(0xFF22C55E), Color(0xFF15803D)))
                        else Brush.verticalGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
                    )
                    .border(
                        1.dp,
                        if (isPlaying) Pa5xNeonGreen else Pa5xChassisBorder,
                        RoundedCornerShape(4.dp)
                    )
                    .clickable { onToggleStartStop() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_arranger_start_stop"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isPlaying) "STOP" else "START",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // SYNCHRO START Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (isSynchroStart) Brush.verticalGradient(listOf(Pa5xNeonCyan, Color(0xFF0284C7)))
                        else Brush.verticalGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
                    )
                    .border(
                        1.dp,
                        if (isSynchroStart) Pa5xNeonCyan else Pa5xChassisBorder,
                        RoundedCornerShape(4.dp)
                    )
                    .clickable { onToggleSynchro() }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("btn_synchro_start"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SYNCHRO",
                    color = if (isSynchroStart) Color.Black else Color.White,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // VARIATION 1-4 Buttons + FILL
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ArrangerVariation.values().forEach { variation ->
                val isSelected = variation == currentVariation
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (isSelected) Brush.verticalGradient(listOf(Pa5xNeonAmber, Color(0xFFD97706)))
                            else Brush.verticalGradient(listOf(Color(0xFF334155), Color(0xFF0F172A)))
                        )
                        .border(
                            1.dp,
                            if (isSelected) Pa5xNeonAmber else Pa5xChassisBorder,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectVariation(variation) }
                        .padding(horizontal = 7.dp, vertical = 6.dp)
                        .testTag("btn_variation_${variation.index + 1}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = variation.label,
                        color = if (isSelected) Color.Black else Color(0xFFE2E8F0),
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Live Arranger FILL Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF334155), Color(0xFF0F172A))))
                    .border(1.dp, Pa5xNeonCyan.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .clickable { onTriggerFill() }
                    .padding(horizontal = 7.dp, vertical = 6.dp)
                    .testTag("btn_arranger_fill"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "FILL",
                    color = Pa5xNeonCyan,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        // Octave Shift Buttons
        if (showOctaves) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF1E293B))
                        .clickable { onOctaveShift(-1) }
                        .padding(horizontal = 6.dp, vertical = 5.dp)
                        .testTag("btn_octave_down"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "OCT -", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .background(Color(0xFF0F172A), RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = if (octaveShift > 0) "+$octaveShift" else "$octaveShift",
                        color = Pa5xNeonCyan,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF1E293B))
                        .clickable { onOctaveShift(1) }
                        .padding(horizontal = 6.dp, vertical = 5.dp)
                        .testTag("btn_octave_up"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "OCT +", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PitchBendModWheels(
    modifier: Modifier = Modifier
) {
    var pitchBendValue by remember { mutableFloatStateOf(0.5f) }
    var modValue by remember { mutableFloatStateOf(0.0f) }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Pa5xChassisCard)
            .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
            .padding(3.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        // Pitch Bend Wheel (Center Spring Return)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "PITCH", color = Color(0xFF94A3B8), fontSize = 7.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .width(18.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF090D16))
                    .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(2.dp))
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { pitchBendValue = 0.5f } // Spring back to center
                        ) { change, dragAmount ->
                            pitchBendValue = (pitchBendValue - dragAmount * 0.01f).coerceIn(0f, 1f)
                            change.consume()
                        }
                    }
            ) {
                // Center detent mark
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .align(Alignment.Center)
                        .background(Pa5xNeonCyan)
                )
                // Wheel rib
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .align(Alignment.TopCenter)
                        .padding(top = ((1f - pitchBendValue) * 45).dp)
                        .background(Color(0xFF64748B))
                )
            }
        }

        Spacer(modifier = Modifier.width(2.dp))

        // Modulation Wheel (Continuous)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "MOD", color = Color(0xFF94A3B8), fontSize = 7.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .width(18.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF090D16))
                    .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(2.dp))
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dragAmount ->
                            modValue = (modValue - dragAmount * 0.01f).coerceIn(0f, 1f)
                            change.consume()
                        }
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .align(Alignment.TopCenter)
                        .padding(top = ((1f - modValue) * 45).dp)
                        .background(Pa5xMagenta)
                )
            }
        }
    }
}
