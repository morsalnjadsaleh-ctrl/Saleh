package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Pa5xDarkColorScheme = darkColorScheme(
    primary = Pa5xMagenta,
    onPrimary = Color.White,
    primaryContainer = Pa5xMagentaDark,
    onPrimaryContainer = Color.White,
    secondary = Pa5xNeonCyan,
    onSecondary = Color.Black,
    secondaryContainer = Pa5xMonitorPanel,
    onSecondaryContainer = Pa5xMonitorText,
    tertiary = Pa5xNeonAmber,
    onTertiary = Color.Black,
    background = Pa5xChassisDark,
    onBackground = Color.White,
    surface = Pa5xChassisCard,
    onSurface = Color.White,
    surfaceVariant = Pa5xChassisBorder,
    onSurfaceVariant = Pa5xMonitorSubtext,
    outline = Pa5xChassisBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = Pa5xDarkColorScheme,
        typography = Typography,
        content = content
    )
}
