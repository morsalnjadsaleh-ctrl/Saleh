package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ArrangerTrackState
import com.example.audio.ArrangerVariation
import com.example.audio.PersianDastgah
import com.example.model.HardwareTier
import com.example.model.SetPackage
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xMonitorBg
import com.example.ui.theme.Pa5xMonitorPanel
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen
import com.example.ui.theme.Pa5xPersianShor

enum class MonitorTab(val label: String) {
    MAIN("PERFORMANCE"),
    MIXER("8-TRACK MIXER"),
    PERSIAN("PERSIAN SCALE"),
    AI_DRUMMER("AI DRUMMER"),
    SETS("SET LOADER")
}

@Composable
fun ArrangerMonitor(
    currentLoadedSetName: String,
    rawKorgCount: Int,
    isRawKorgLocked: Boolean,
    hardwareTier: HardwareTier,
    currentDastgah: PersianDastgah,
    isAntiFalschEnabled: Boolean,
    isArrangerPlaying: Boolean,
    isSynchroStart: Boolean,
    currentVariation: ArrangerVariation,
    bpm: Int,
    currentStep: Int,
    currentBeat: Int,
    trackStates: List<ArrangerTrackState>,
    trackVus: FloatArray,
    aiComplexity: Int,
    aiHumanize: Float,
    onTrackVolumeChange: (Int, Float) -> Unit,
    onTrackToggleMute: (Int) -> Unit,
    onTrackToggleSolo: (Int) -> Unit,
    onDastgahSelect: (PersianDastgah) -> Unit,
    onToggleAntiFalsch: () -> Unit,
    onAiComplexityChange: (Int) -> Unit,
    onAiHumanizeChange: (Float) -> Unit,
    onAiAutoConfig: () -> Unit,
    onLoadRawKorgSet: (SetPackage) -> Unit,
    onLoadEncryptedSet: (SetPackage) -> Unit,
    onOpenTelegram: () -> Unit,
    onResetTrial: () -> Unit,
    onBpmChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(MonitorTab.MAIN) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Pa5xMonitorBg)
            .border(1.dp, Pa5xChassisBorder, RoundedCornerShape(6.dp))
            .padding(4.dp)
            .testTag("arranger_monitor")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Monitor Top Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Pa5xMonitorPanel)
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Active Loaded Set
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(Pa5xMagenta, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "SET",
                            color = Color.White,
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = currentLoadedSetName,
                        color = Color.White,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                // Center: BPM & Beat Counter
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "TEMPO:",
                        color = Color(0xFF94A3B8),
                        fontSize = 8.sp
                    )
                    Text(
                        text = "$bpm BPM",
                        color = Pa5xNeonCyan,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF0F172A), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "BEAT: $currentBeat/4",
                            color = if (isArrangerPlaying) Pa5xNeonGreen else Color(0xFF64748B),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Right: Active Mode & Hardware Tier Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                if (isAntiFalschEnabled) Pa5xNeonGreen.copy(alpha = 0.2f) else Color(0xFF1E293B),
                                RoundedCornerShape(2.dp)
                            )
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = if (isAntiFalschEnabled) "ANTI-FALSCH" else "FREE PITCH",
                            color = if (isAntiFalschEnabled) Pa5xNeonGreen else Color(0xFF94A3B8),
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Pa5xChassisBorder, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = hardwareTier.name.replace("_", " "),
                            color = Pa5xNeonAmber,
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            // Navigation Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                MonitorTab.values().forEach { tab ->
                    val isSelected = tab == selectedTab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isSelected) Pa5xMagenta else Pa5xChassisCard)
                            .clickable { selectedTab = tab }
                            .padding(vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab.label,
                            color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                            fontSize = 8.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    MonitorTab.MAIN -> MainPerformancePane(
                        bpm = bpm,
                        isArrangerPlaying = isArrangerPlaying,
                        isSynchroStart = isSynchroStart,
                        currentVariation = currentVariation,
                        currentDastgah = currentDastgah,
                        rawKorgCount = rawKorgCount,
                        isRawKorgLocked = isRawKorgLocked,
                        onBpmChange = onBpmChange,
                        onOpenSetsTab = { selectedTab = MonitorTab.SETS },
                        onOpenMixerTab = { selectedTab = MonitorTab.MIXER }
                    )
                    MonitorTab.MIXER -> TrackMixerPane(
                        tracks = trackStates,
                        vuLevels = trackVus,
                        hardwareTier = hardwareTier,
                        onVolumeChange = onTrackVolumeChange,
                        onToggleMute = onTrackToggleMute,
                        onToggleSolo = onTrackToggleSolo
                    )
                    MonitorTab.PERSIAN -> PersianScalePane(
                        currentDastgah = currentDastgah,
                        isAntiFalschEnabled = isAntiFalschEnabled,
                        onDastgahSelect = onDastgahSelect,
                        onToggleAntiFalsch = onToggleAntiFalsch
                    )
                    MonitorTab.AI_DRUMMER -> AiDrummerPane(
                        complexity = aiComplexity,
                        humanize = aiHumanize,
                        currentStep = currentStep,
                        currentBeat = currentBeat,
                        onComplexityChange = onAiComplexityChange,
                        onHumanizeChange = onAiHumanizeChange,
                        onAutoConfig = onAiAutoConfig
                    )
                    MonitorTab.SETS -> SetLoaderPane(
                        rawKorgCount = rawKorgCount,
                        isRawKorgLocked = isRawKorgLocked,
                        currentLoadedSetName = currentLoadedSetName,
                        onLoadRawKorgSet = onLoadRawKorgSet,
                        onLoadEncryptedSet = onLoadEncryptedSet,
                        onOpenTelegram = onOpenTelegram,
                        onResetTrial = onResetTrial
                    )
                }
            }
        }
    }
}

@Composable
private fun MainPerformancePane(
    bpm: Int,
    isArrangerPlaying: Boolean,
    isSynchroStart: Boolean,
    currentVariation: ArrangerVariation,
    currentDastgah: PersianDastgah,
    rawKorgCount: Int,
    isRawKorgLocked: Boolean,
    onBpmChange: (Int) -> Unit,
    onOpenSetsTab: () -> Unit,
    onOpenMixerTab: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Pa5xMonitorBg)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Left Column: Grand Piano Sound & Sound Generator Status
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(Pa5xChassisCard)
                .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
                .padding(6.dp)
        ) {
            Text(
                text = "UPPER 1: CONCERT GRAND PIANO",
                color = Pa5xNeonCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Native Dynamic Pitch-Shift Physical Model",
                color = Color(0xFF94A3B8),
                fontSize = 8.sp
            )
            Spacer(modifier = Modifier.height(4.dp))

            // Dynamic Pitch Shift Status Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(3.dp))
                    .padding(4.dp)
            ) {
                Column {
                    Text(
                        text = "PITCH-SHIFT FREQ LOGIC: ACTIVE",
                        color = Pa5xNeonGreen,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Formula: f = 440 × 2^((midi - 69 + cents/100) / 12)",
                        color = Color(0xFF64748B),
                        fontSize = 7.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Persian Dastgah Info
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF020617), RoundedCornerShape(3.dp))
                    .padding(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ACTIVE SCALE MODE:",
                            color = Color(0xFF94A3B8),
                            fontSize = 7.5.sp
                        )
                        Text(
                            text = currentDastgah.titleFa,
                            color = Pa5xPersianShor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = currentDastgah.titleEn,
                        color = Color.White,
                        fontSize = 8.5.sp
                    )
                }
            }
        }

        // Right Column: Arranger Status, Variation & Tempo Adjuster
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(4.dp))
                .background(Pa5xChassisCard)
                .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
                .padding(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ARRANGER: 8-TRACK ENGINE",
                    color = Pa5xMagenta,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isArrangerPlaying) "● PLAYING" else if (isSynchroStart) "SYNCHRO ARMED" else "STOPPED",
                    color = if (isArrangerPlaying) Pa5xNeonGreen else if (isSynchroStart) Pa5xNeonCyan else Color(0xFF64748B),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(3.dp))

            // Current Variation badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(3.dp))
                    .padding(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STYLE INTENSITY: ${currentVariation.label}",
                        color = Pa5xNeonAmber,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = currentVariation.description.substringBefore(" /"),
                        color = Color(0xFFCBD5E1),
                        fontSize = 7.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Tempo +/- adjuster
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TEMPO BARS:", color = Color(0xFF94A3B8), fontSize = 8.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(0xFF334155))
                            .clickable { onBpmChange(bpm - 2) }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "-2", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(0xFF334155))
                            .clickable { onBpmChange(bpm + 2) }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "+2", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Quick links to Mixer & Sets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF0F172A))
                        .clickable { onOpenMixerTab() }
                        .padding(vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Open 8-Tr Faders", color = Pa5xNeonCyan, fontSize = 7.5.sp)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF0F172A))
                        .clickable { onOpenSetsTab() }
                        .padding(vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isRawKorgLocked) "Sets (Locked)" else "Load Sets ($rawKorgCount/2)",
                        color = if (isRawKorgLocked) Color(0xFFEF4444) else Pa5xNeonAmber,
                        fontSize = 7.5.sp
                    )
                }
            }
        }
    }
}
