package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xMonitorBg
import com.example.ui.theme.Pa5xNeonAmber
import com.example.ui.theme.Pa5xNeonCyan

@Composable
fun AiDrummerPane(
    complexity: Int,
    humanize: Float,
    currentStep: Int,
    currentBeat: Int,
    onComplexityChange: (Int) -> Unit,
    onHumanizeChange: (Float) -> Unit,
    onAutoConfig: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Pa5xMonitorBg)
            .padding(6.dp)
            .testTag("ai_drummer_pane")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Pa5xChassisCard, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "KORG Pa5X AI DRUMMER ENGINE",
                    color = Pa5xNeonAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "NEURAL GROOVE & ADAPTIVE FILLS",
                    color = Color(0xFF94A3B8),
                    fontSize = 9.sp
                )
            }

            Button(
                onClick = onAutoConfig,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Pa5xMagenta,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(4.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(24.dp)
                    .testTag("btn_ai_auto_config")
            ) {
                Text(
                    text = "⚡ AUTO CONFIG",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 16-step rhythm visualizer bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF020617), RoundedCornerShape(4.dp))
                .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            for (step in 0..15) {
                val isActiveStep = step == currentStep
                val isBeatDown = step % 4 == 0
                val barColor = when {
                    isActiveStep -> Pa5xNeonCyan
                    isBeatDown -> Color(0xFF334155)
                    else -> Color(0xFF1E293B)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(barColor),
                    contentAlignment = Alignment.Center
                ) {
                    if (isBeatDown) {
                        Text(
                            text = "${(step / 4) + 1}",
                            color = Color(0xFF94A3B8),
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Complexity Slider
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "COMPLEXITY", color = Color(0xFFCBD5E1), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Tier $complexity/5", color = Pa5xNeonAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = complexity.toFloat(),
                    onValueChange = { onComplexityChange(it.toInt()) },
                    valueRange = 1f..5f,
                    steps = 3,
                    colors = SliderDefaults.colors(
                        thumbColor = Pa5xNeonAmber,
                        activeTrackColor = Pa5xNeonAmber,
                        inactiveTrackColor = Color(0xFF334155)
                    ),
                    modifier = Modifier.testTag("ai_complexity_slider")
                )
            }

            // Humanize Slider
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "HUMANIZE (JITTER & GROOVE)", color = Color(0xFFCBD5E1), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${(humanize * 100).toInt()}%", color = Pa5xNeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = humanize,
                    onValueChange = onHumanizeChange,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = Pa5xNeonCyan,
                        activeTrackColor = Pa5xNeonCyan,
                        inactiveTrackColor = Color(0xFF334155)
                    ),
                    modifier = Modifier.testTag("ai_humanize_slider")
                )
            }
        }
    }
}
