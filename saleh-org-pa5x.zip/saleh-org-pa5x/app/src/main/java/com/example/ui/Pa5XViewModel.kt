package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.ArrangerEngine
import com.example.audio.ArrangerTrackState
import com.example.audio.ArrangerVariation
import com.example.audio.AudioEngine
import com.example.audio.PersianDastgah
import com.example.model.HardwareTier
import com.example.model.LayoutConfig
import com.example.model.SetFileType
import com.example.model.SetPackage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class Pa5XViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("saleh_pa5x_prefs", Context.MODE_PRIVATE)

    val audioEngine = AudioEngine(viewModelScope)
    val arrangerEngine = ArrangerEngine(viewModelScope, audioEngine)

    // Hardware Scaling Tier (Tier 1: Ultra Flagship, Tier 2: Mid-Range, Tier 3: Budget Anti-Lag)
    private val _hardwareTier = MutableStateFlow(
        HardwareTier.valueOf(prefs.getString("pref_hardware_tier", HardwareTier.TIER_1.name) ?: HardwareTier.TIER_1.name)
    )
    val hardwareTier: StateFlow<HardwareTier> = _hardwareTier.asStateFlow()

    // Custom Layout Settings
    private val _layoutConfig = MutableStateFlow(loadLayoutConfig())
    val layoutConfig: StateFlow<LayoutConfig> = _layoutConfig.asStateFlow()

    // Persian Tuning & Anti-Falsch
    private val _currentDastgah = MutableStateFlow(PersianDastgah.SHOR)
    val currentDastgah: StateFlow<PersianDastgah> = _currentDastgah.asStateFlow()

    private val _isAntiFalschEnabled = MutableStateFlow(true)
    val isAntiFalschEnabled: StateFlow<Boolean> = _isAntiFalschEnabled.asStateFlow()

    // 2-Set Free Trial & Encrypted Loader
    private val _rawKorgSetCount = MutableStateFlow(prefs.getInt("pref_raw_korg_count", 0))
    val rawKorgSetCount: StateFlow<Int> = _rawKorgSetCount.asStateFlow()

    private val _currentLoadedSetName = MutableStateFlow(
        prefs.getString("pref_current_set_name", "Saleh Factory Pa5X VIP Set") ?: "Saleh Factory Pa5X VIP Set"
    )
    val currentLoadedSetName: StateFlow<String> = _currentLoadedSetName.asStateFlow()

    private val _isRawKorgSetLocked = MutableStateFlow(_rawKorgSetCount.value >= 2)
    val isRawKorgSetLocked: StateFlow<Boolean> = _isRawKorgSetLocked.asStateFlow()

    private val _showTrialLimitDialog = MutableStateFlow(false)
    val showTrialLimitDialog: StateFlow<Boolean> = _showTrialLimitDialog.asStateFlow()

    // OTG / USB Auto-Docking Mode
    private val _isOtgDocked = MutableStateFlow(false)
    val isOtgDocked: StateFlow<Boolean> = _isOtgDocked.asStateFlow()

    // Octave Shift (-2 to +2)
    private val _octaveShift = MutableStateFlow(0)
    val octaveShift: StateFlow<Int> = _octaveShift.asStateFlow()

    // Currently held MIDI notes for visual key highlighting
    private val _pressedNotes = MutableStateFlow<Set<Int>>(emptySet())
    val pressedNotes: StateFlow<Set<Int>> = _pressedNotes.asStateFlow()

    // Arranger Sequencer State
    private val _isArrangerPlaying = MutableStateFlow(false)
    val isArrangerPlaying: StateFlow<Boolean> = _isArrangerPlaying.asStateFlow()

    private val _isSynchroStart = MutableStateFlow(false)
    val isSynchroStart: StateFlow<Boolean> = _isSynchroStart.asStateFlow()

    private val _currentVariation = MutableStateFlow(ArrangerVariation.VAR_1)
    val currentVariation: StateFlow<ArrangerVariation> = _currentVariation.asStateFlow()

    private val _bpm = MutableStateFlow(118)
    val bpm: StateFlow<Int> = _bpm.asStateFlow()

    private val _currentStep = MutableStateFlow(0)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _currentBeat = MutableStateFlow(1)
    val currentBeat: StateFlow<Int> = _currentBeat.asStateFlow()

    private val _trackVuLevels = MutableStateFlow(FloatArray(8) { 0f })
    val trackVuLevels: StateFlow<FloatArray> = _trackVuLevels.asStateFlow()

    private val _trackStates = MutableStateFlow(arrangerEngine.tracks.toList())
    val trackStates: StateFlow<List<ArrangerTrackState>> = _trackStates.asStateFlow()

    // AI Drummer Parameters
    private val _aiComplexity = MutableStateFlow(3)
    val aiComplexity: StateFlow<Int> = _aiComplexity.asStateFlow()

    private val _aiHumanize = MutableStateFlow(0.25f)
    val aiHumanize: StateFlow<Float> = _aiHumanize.asStateFlow()

    // Dialog Toggles
    val showSettingsDialog = MutableStateFlow(false)
    val showLayoutEditorDialog = MutableStateFlow(false)
    val showSetLoaderDialog = MutableStateFlow(false)

    // Map of active note pointers to sound voice ID
    private val activePointerVoiceMap = mutableMapOf<Int, Int>()

    init {
        audioEngine.setHardwareTier(_hardwareTier.value)
        audioEngine.start()

        arrangerEngine.onStepListener = { step, beat, vus ->
            _currentStep.value = step
            _currentBeat.value = beat
            _trackVuLevels.value = vus
        }
    }

    override fun onCleared() {
        super.onCleared()
        arrangerEngine.stop()
        audioEngine.stop()
    }

    // -------------------------------------------------------------
    // Audio & Keyboard Triggers
    // -------------------------------------------------------------

    fun onKeyDown(pointerId: Int, midiNote: Int, velocity: Int = 105) {
        val dastgah = _currentDastgah.value
        val isAntiFalsch = _isAntiFalschEnabled.value

        // Anti-Falsch logic: snap discordant note to closest scale note
        val playedNote = PersianDastgah.snapNoteIfAntiFalsch(midiNote, dastgah, isAntiFalsch)
        val noteDegree = ((playedNote % 12) + 12) % 12
        val cents = dastgah.centsOffsets[noteDegree]

        // Dynamic pitch shifting with Persian microtonal cents
        val voiceId = audioEngine.noteOn(playedNote, velocity, cents)
        activePointerVoiceMap[pointerId] = voiceId

        _pressedNotes.update { it + playedNote }

        // Synchro start trigger for arranger
        arrangerEngine.triggerFromKeyboard(playedNote)
        _isArrangerPlaying.value = arrangerEngine.isPlaying.get()
        _isSynchroStart.value = arrangerEngine.isSynchroStartArmed.get()
    }

    fun onKeyUp(pointerId: Int) {
        activePointerVoiceMap.remove(pointerId)?.let { voiceId ->
            audioEngine.noteOff(voiceId)
        }
        if (activePointerVoiceMap.isEmpty()) {
            _pressedNotes.value = emptySet()
        }
    }

    fun clearAllKeys() {
        activePointerVoiceMap.values.forEach { audioEngine.noteOff(it) }
        activePointerVoiceMap.clear()
        _pressedNotes.value = emptySet()
    }

    fun shiftOctave(delta: Int) {
        _octaveShift.update { (it + delta).coerceIn(-2, 2) }
    }

    // -------------------------------------------------------------
    // Arranger Controls
    // -------------------------------------------------------------

    fun toggleArrangerStartStop() {
        val playing = arrangerEngine.toggleStartStop()
        _isArrangerPlaying.value = playing
        _isSynchroStart.value = arrangerEngine.isSynchroStartArmed.get()
    }

    fun toggleSynchroStart() {
        val armed = arrangerEngine.toggleSynchroStart()
        _isSynchroStart.value = armed
        _isArrangerPlaying.value = arrangerEngine.isPlaying.get()
    }

    fun setVariation(variation: ArrangerVariation) {
        arrangerEngine.setVariation(variation)
        _currentVariation.value = variation
    }

    fun setBpm(newBpm: Int) {
        val clamped = newBpm.coerceIn(60, 220)
        arrangerEngine.bpm = clamped
        _bpm.value = clamped
    }

    fun adjustBpm(delta: Int) {
        setBpm(_bpm.value + delta)
    }

    fun triggerMatrixPad(padIndex: Int) {
        // Pa5X 4-Matrix Pads for live fills and oriental acoustic hits
        val midiNote = when (padIndex) {
            0 -> 60 // Tombak Dum (deep resonant pulse)
            1 -> 61 // Tombak Tek (sharp snap)
            2 -> 42 // Percussion / Daf shaker
            3 -> 49 // Crash Cymbal / Live Accent
            else -> 60
        }
        audioEngine.triggerDrum(midiNote, 0.95f)
    }

    fun setMasterVolume(vol: Float) {
        audioEngine.masterVolume = vol.coerceIn(0f, 1f)
    }

    fun setTrackVolume(trackIndex: Int, volume: Float) {
        arrangerEngine.setTrackVolume(trackIndex, volume)
        _trackStates.value = arrangerEngine.tracks.toList()
    }

    fun toggleTrackMute(trackIndex: Int) {
        arrangerEngine.toggleTrackMute(trackIndex)
        _trackStates.value = arrangerEngine.tracks.toList()
    }

    fun toggleTrackSolo(trackIndex: Int) {
        arrangerEngine.toggleTrackSolo(trackIndex)
        _trackStates.value = arrangerEngine.tracks.toList()
    }

    fun setAiComplexity(value: Int) {
        arrangerEngine.aiComplexity = value
        _aiComplexity.value = value
    }

    fun setAiHumanize(value: Float) {
        arrangerEngine.aiHumanize = value
        _aiHumanize.value = value
    }

    fun autoConfigAiDrummer() {
        arrangerEngine.autoConfigAiDrummer()
        _aiComplexity.value = arrangerEngine.aiComplexity
        _aiHumanize.value = arrangerEngine.aiHumanize
        Toast.makeText(getApplication(), "AI Drummer Auto-Configured!", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------------------------------------
    // Persian Tuning & Scales
    // -------------------------------------------------------------

    fun setDastgah(dastgah: PersianDastgah) {
        _currentDastgah.value = dastgah
    }

    fun toggleAntiFalsch() {
        _isAntiFalschEnabled.update { !it }
    }

    // -------------------------------------------------------------
    // Hardware Tier Scaling Engine
    // -------------------------------------------------------------

    fun setHardwareTier(tier: HardwareTier) {
        _hardwareTier.value = tier
        prefs.edit().putString("pref_hardware_tier", tier.name).apply()
        audioEngine.setHardwareTier(tier)
        Toast.makeText(getApplication(), "Switched to ${tier.title}", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------------------------------------
    // 2-Set Free Trial & Encrypted Secure Loader Engine
    // -------------------------------------------------------------

    fun loadRawKorgSet(pkg: SetPackage): Boolean {
        val currentCount = _rawKorgSetCount.value
        if (currentCount >= 2) {
            _isRawKorgSetLocked.value = true
            _showTrialLimitDialog.value = true
            return false
        }

        val newCount = currentCount + 1
        _rawKorgSetCount.value = newCount
        _currentLoadedSetName.value = pkg.name
        prefs.edit()
            .putInt("pref_raw_korg_count", newCount)
            .putString("pref_current_set_name", pkg.name)
            .apply()

        if (newCount >= 2) {
            _isRawKorgSetLocked.value = true
        }

        Toast.makeText(
            getApplication(),
            "Loaded Raw Korg .SET (${newCount}/2 Free Trial Loads Used)",
            Toast.LENGTH_LONG
        ).show()
        return true
    }

    fun loadSalehEncryptedSet(pkg: SetPackage) {
        // Unlimited loading allowed for proprietary encrypted formats (.saleh / .sp5x)
        _currentLoadedSetName.value = pkg.name
        prefs.edit().putString("pref_current_set_name", pkg.name).apply()
        Toast.makeText(
            getApplication(),
            "VIP Authenticated: ${pkg.name} loaded with zero latency!",
            Toast.LENGTH_LONG
        ).show()
    }

    fun dismissTrialLimitDialog() {
        _showTrialLimitDialog.value = false
    }

    fun openTelegramShop() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/SalehOrgBot")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/morsalsalh")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                getApplication<Application>().startActivity(fallbackIntent)
            } catch (_: Exception) {
                Toast.makeText(getApplication(), "Telegram bot link: https://t.me/SalehOrgBot", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun resetTrialForTesting() {
        _rawKorgSetCount.value = 0
        _isRawKorgSetLocked.value = false
        prefs.edit().putInt("pref_raw_korg_count", 0).apply()
        Toast.makeText(getApplication(), "Raw Korg Set trial reset to 0/2", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------------------------------------
    // Custom Layout Settings
    // -------------------------------------------------------------

    fun updateLayoutConfig(newConfig: LayoutConfig) {
        _layoutConfig.value = newConfig
        saveLayoutConfig(newConfig)
    }

    fun resetLayoutToFactory() {
        val defaultConfig = LayoutConfig()
        _layoutConfig.value = defaultConfig
        saveLayoutConfig(defaultConfig)
        Toast.makeText(getApplication(), "Layout reset to factory defaults", Toast.LENGTH_SHORT).show()
    }

    private fun loadLayoutConfig(): LayoutConfig {
        return LayoutConfig(
            monitorScale = prefs.getFloat("layout_monitor_scale", 1.0f),
            controlsScale = prefs.getFloat("layout_controls_scale", 1.0f),
            keyboardHeightRatio = prefs.getFloat("layout_kb_height", 0.38f),
            showPitchBendMod = prefs.getBoolean("layout_show_pitchbend", true),
            show8TrackMixer = prefs.getBoolean("layout_show_mixer", true),
            showPersianQuickBar = prefs.getBoolean("layout_show_persian", true),
            showAiDrummerBox = prefs.getBoolean("layout_show_ai_drummer", true),
            showVariationBar = prefs.getBoolean("layout_show_var_bar", true),
            showOctaveControls = prefs.getBoolean("layout_show_octaves", true),
            showPersianKeyLabels = prefs.getBoolean("layout_show_fa_labels", true),
            showEnglishKeyLabels = prefs.getBoolean("layout_show_en_labels", true)
        )
    }

    private fun saveLayoutConfig(config: LayoutConfig) {
        prefs.edit()
            .putFloat("layout_monitor_scale", config.monitorScale)
            .putFloat("layout_controls_scale", config.controlsScale)
            .putFloat("layout_kb_height", config.keyboardHeightRatio)
            .putBoolean("layout_show_pitchbend", config.showPitchBendMod)
            .putBoolean("layout_show_mixer", config.show8TrackMixer)
            .putBoolean("layout_show_persian", config.showPersianQuickBar)
            .putBoolean("layout_show_ai_drummer", config.showAiDrummerBox)
            .putBoolean("layout_show_var_bar", config.showVariationBar)
            .putBoolean("layout_show_octaves", config.showOctaveControls)
            .putBoolean("layout_show_fa_labels", config.showPersianKeyLabels)
            .putBoolean("layout_show_en_labels", config.showEnglishKeyLabels)
            .apply()
    }

    // -------------------------------------------------------------
    // OTG Docking Mode
    // -------------------------------------------------------------

    fun toggleOtgDocking() {
        _isOtgDocked.update { !it }
        val msg = if (_isOtgDocked.value) {
            "USB/OTG Docked: Virtual keys hidden, Chassis expanded for external MIDI keyboard"
        } else {
            "Virtual Keyboard restored"
        }
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }
}
