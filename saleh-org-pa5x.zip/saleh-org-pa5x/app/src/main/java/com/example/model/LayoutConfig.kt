package com.example.model

data class LayoutConfig(
    val monitorScale: Float = 1.0f,
    val controlsScale: Float = 1.0f,
    val keyboardHeightRatio: Float = 0.38f,
    val showPitchBendMod: Boolean = true,
    val show8TrackMixer: Boolean = true,
    val showPersianQuickBar: Boolean = true,
    val showAiDrummerBox: Boolean = true,
    val showVariationBar: Boolean = true,
    val showOctaveControls: Boolean = true,
    val showPersianKeyLabels: Boolean = true,
    val showEnglishKeyLabels: Boolean = true
)
