package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PersianDastgah
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xMonitorBg
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen
import com.example.ui.theme.Pa5xPersianShor

@Composable
fun PersianScalePane(
    currentDastgah: PersianDastgah,
    isAntiFalschEnabled: Boolean,
    onDastgahSelect: (PersianDastgah) -> Unit,
    onToggleAntiFalsch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Pa5xMonitorBg)
            .padding(6.dp)
            .testTag("persian_scale_pane")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Pa5xChassisCard, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "PERSIAN SCALE & ANTI-FALSCH ENGINE",
                    color = Pa5xPersianShor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(Pa5xPersianShor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "ORIENTAL QUARTER-TONE MODES",
                        color = Pa5xPersianShor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Anti-Falsch Live Lock Toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = if (isAntiFalschEnabled) "ANTI-FALSCH ACTIVE (LOCKED)" else "ANTI-FALSCH OFF",
                    color = if (isAntiFalschEnabled) Pa5xNeonGreen else Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
                Switch(
                    checked = isAntiFalschEnabled,
                    onCheckedChange = { onToggleAntiFalsch() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Pa5xNeonGreen,
                        checkedTrackColor = Color(0xFF064E3B),
                        uncheckedThumbColor = Color(0xFF64748B),
                        uncheckedTrackColor = Color(0xFF1E293B)
                    ),
                    modifier = Modifier.testTag("anti_falsch_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Dastgah Preset Selector Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            PersianDastgah.values().forEach { dastgah ->
                val isSelected = dastgah == currentDastgah
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) Pa5xPersianShor.copy(alpha = 0.25f) else Pa5xChassisCard)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.5.dp,
                            color = if (isSelected) Pa5xPersianShor else Pa5xChassisBorder,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onDastgahSelect(dastgah) }
                        .padding(vertical = 6.dp, horizontal = 2.dp)
                        .testTag("dastgah_${dastgah.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = dastgah.name.replace("_", " "),
                            color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = dastgah.titleFa,
                            color = if (isSelected) Pa5xPersianShor else Color(0xFF94A3B8),
                            fontSize = 8.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Microtonal Quarter-Tone Visual Matrix (C, D, E, F, G, A, B notes with Koron indicators)
        val noteLabels = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF020617), RoundedCornerShape(4.dp))
                .border(0.5.dp, Pa5xChassisBorder, RoundedCornerShape(4.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            noteLabels.forEachIndexed { degree, label ->
                val offsetCents = currentDastgah.centsOffsets[degree]
                val isKoron = offsetCents == -50
                val isAllowed = degree in currentDastgah.allowedDegrees

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isKoron) Color(0xFF064E3B) else Color(0xFF0F172A))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = label,
                        color = if (isAllowed) Color.White else Color(0xFF475569),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isKoron) "-50¢ p" else "0¢",
                        color = if (isKoron) Pa5xNeonGreen else Color(0xFF64748B),
                        fontSize = 8.sp,
                        fontWeight = if (isKoron) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Description: ${currentDastgah.description}",
            color = Color(0xFF94A3B8),
            fontSize = 9.sp,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
