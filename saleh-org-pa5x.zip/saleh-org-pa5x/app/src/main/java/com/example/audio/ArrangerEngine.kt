package com.example.audio

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

data class ArrangerTrackState(
    val name: String,
    val channel: Int,
    val volume: Float = 0.85f,
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val vuLevel: Float = 0.0f
)

enum class ArrangerVariation(val label: String, val index: Int, val description: String) {
    VAR_1("VAR 1", 0, "Basic Groove / Acoustic Intimate"),
    VAR_2("VAR 2", 1, "Medium Drive / Standard Accompaniment"),
    VAR_3("VAR 3", 2, "Rich Energy / Polyrhythmic Percussion"),
    VAR_4("VAR 4", 3, "Peak Crescendo / Full 8-Track Band")
}

class ArrangerEngine(
    private val coroutineScope: CoroutineScope,
    private val audioEngine: AudioEngine
) {
    val isPlaying = AtomicBoolean(false)
    var isSynchroStartArmed = AtomicBoolean(false)

    var bpm: Int = 118
    var currentVariation: ArrangerVariation = ArrangerVariation.VAR_1
    var currentStep: Int = 0
        private set

    // AI Drummer settings
    var aiComplexity: Int = 3 // 1 to 5
    var aiHumanize: Float = 0.25f // 0.0 to 1.0 timing/velocity jitter

    // 8 Tracks hierarchy according to Korg Pa5X specification
    val tracks = Array(8) { index ->
        when (index) {
            0 -> ArrangerTrackState(name = "Drum (Ch 10)", channel = 10, volume = 0.9f)
            1 -> ArrangerTrackState(name = "Percussion", channel = 11, volume = 0.85f)
            2 -> ArrangerTrackState(name = "Bass", channel = 9, volume = 0.85f)
            3 -> ArrangerTrackState(name = "ACC 1 (Pad)", channel = 4, volume = 0.75f)
            4 -> ArrangerTrackState(name = "ACC 2 (Piano)", channel = 5, volume = 0.8f)
            5 -> ArrangerTrackState(name = "ACC 3 (Strings)", channel = 6, volume = 0.75f)
            6 -> ArrangerTrackState(name = "ACC 4 (Lead)", channel = 7, volume = 0.7f)
            7 -> ArrangerTrackState(name = "ACC 5 (FX)", channel = 8, volume = 0.65f)
            else -> ArrangerTrackState("Track ${index + 1}", index + 1)
        }
    }

    private var sequencerJob: Job? = null
    var onStepListener: ((step: Int, beat: Int, vuLevels: FloatArray) -> Unit)? = null

    // Base root note for accompaniment (e.g. 60 = C4, 57 = A3)
    var activeChordRoot: Int = 60

    fun start() {
        if (isPlaying.getAndSet(true)) return
        isSynchroStartArmed.set(false)
        currentStep = 0
        sequencerJob = coroutineScope.launch(Dispatchers.Default) {
            val stepVus = FloatArray(8)

            while (isActive && isPlaying.get()) {
                val stepDurationMs = (60_000L / bpm) / 4 // 16th note steps

                // Play events for current step across 8 tracks
                playStep(currentStep, stepVus)

                // Notify UI listener with step & VU meter peaks
                val beat = (currentStep / 4) + 1
                onStepListener?.invoke(currentStep, beat, stepVus.clone())

                // Decay VUs
                for (v in stepVus.indices) {
                    stepVus[v] = (stepVus[v] * 0.75f).coerceAtLeast(0f)
                }

                currentStep = (currentStep + 1) % 16

                // Apply AI Drummer micro-timing humanize jitter if enabled
                val jitterMs = if (aiHumanize > 0.05f) {
                    ((Random.nextFloat() - 0.5f) * aiHumanize * 18.0f).toLong()
                } else 0L

                val delayTime = (stepDurationMs + jitterMs).coerceAtLeast(10L)
                delay(delayTime)
            }
        }
    }

    fun stop() {
        isPlaying.set(false)
        sequencerJob?.cancel()
        sequencerJob = null
        currentStep = 0
        onStepListener?.invoke(0, 1, FloatArray(8) { 0f })
    }

    fun toggleStartStop(): Boolean {
        if (isPlaying.get()) {
            stop()
            return false
        } else {
            start()
            return true
        }
    }

    fun toggleSynchroStart(): Boolean {
        val newState = !isSynchroStartArmed.get()
        isSynchroStartArmed.set(newState)
        if (newState && isPlaying.get()) {
            stop()
        }
        return newState
    }

    fun triggerFromKeyboard(chordNote: Int) {
        activeChordRoot = chordNote
        if (isSynchroStartArmed.get() && !isPlaying.get()) {
            isSynchroStartArmed.set(false)
            start()
        }
    }

    fun setVariation(variation: ArrangerVariation) {
        currentVariation = variation
    }

    fun setTrackVolume(trackIndex: Int, volume: Float) {
        if (trackIndex in 0..7) {
            tracks[trackIndex] = tracks[trackIndex].copy(volume = volume.coerceIn(0f, 1f))
        }
    }

    fun toggleTrackMute(trackIndex: Int) {
        if (trackIndex in 0..7) {
            tracks[trackIndex] = tracks[trackIndex].copy(isMuted = !tracks[trackIndex].isMuted)
        }
    }

    fun toggleTrackSolo(trackIndex: Int) {
        if (trackIndex in 0..7) {
            val currentSolo = tracks[trackIndex].isSolo
            for (i in 0..7) {
                tracks[i] = tracks[i].copy(isSolo = if (i == trackIndex) !currentSolo else false)
            }
        }
    }

    /**
     * AI Drummer Auto Config: Generates dynamic live fills & adjusts groove complexity
     */
    fun autoConfigAiDrummer() {
        aiComplexity = (2..5).random()
        aiHumanize = (15..45).random() / 100.0f
    }

    private fun playStep(step: Int, vus: FloatArray) {
        val hasSolo = tracks.any { it.isSolo }
        val varIdx = currentVariation.index
        val complexity = aiComplexity

        // Humanize velocity variance
        fun applyVelVariance(base: Float): Float {
            if (aiHumanize <= 0.05f) return base
            val variance = (Random.nextFloat() - 0.5f) * aiHumanize * 0.4f
            return (base + variance).coerceIn(0.1f, 1.0f)
        }

        // Helper to check if track is audible
        fun isAudible(idx: Int): Boolean {
            val t = tracks[idx]
            if (hasSolo) return t.isSolo
            return !t.isMuted
        }

        // --- TRACK 0: DRUM (Korg Channel 10) ---
        if (isAudible(0)) {
            val vol = tracks[0].volume
            // Kick (Note 36) on 0, 8, plus variation syncopations
            val kickHits = when (varIdx) {
                0 -> step == 0 || step == 8
                1 -> step == 0 || step == 6 || step == 8 || step == 14
                2 -> step == 0 || step == 4 || step == 8 || step == 11 || (complexity >= 4 && step == 14)
                else -> step == 0 || step == 3 || step == 6 || step == 8 || step == 11 || step == 14
            }
            if (kickHits) {
                audioEngine.triggerDrum(36, applyVelVariance(0.95f), vol)
                vus[0] = 0.95f
            }

            // Snare (Note 38) on 4, 12, plus ghost notes
            val snareHits = (step == 4 || step == 12)
            val snareGhost = (varIdx >= 2 && (step == 7 || step == 15) && complexity >= 3)
            if (snareHits) {
                audioEngine.triggerDrum(38, applyVelVariance(0.9f), vol)
                vus[0] = kotlin.math.max(vus[0], 0.9f)
            } else if (snareGhost) {
                audioEngine.triggerDrum(38, applyVelVariance(0.45f), vol)
                vus[0] = kotlin.math.max(vus[0], 0.45f)
            }

            // Hi-Hats: 42 (Closed) on every 8th/16th, 46 (Open) on upbeats
            val openHh = (step == 6 || step == 14) && varIdx >= 1
            val closedHh = when {
                openHh -> false
                varIdx == 0 -> step % 4 == 0 || step % 4 == 2
                else -> step % 2 == 0 || (complexity >= 4 && step % 4 == 1)
            }
            if (openHh) {
                audioEngine.triggerDrum(46, applyVelVariance(0.7f), vol)
                vus[0] = kotlin.math.max(vus[0], 0.7f)
            } else if (closedHh) {
                audioEngine.triggerDrum(42, applyVelVariance(if (step % 4 == 0) 0.75f else 0.5f), vol)
                vus[0] = kotlin.math.max(vus[0], 0.6f)
            }

            // Crash on step 0 if Var 4 or Var 3 start
            if (step == 0 && varIdx >= 3) {
                audioEngine.triggerDrum(49, 0.8f, vol)
                vus[0] = 1.0f
            }
        }

        // --- TRACK 1: PERCUSSION (Tombak / Daf / Shaker / Claps) ---
        if (isAudible(1)) {
            val vol = tracks[1].volume
            if (varIdx >= 1) {
                // Persian Tombak Dum / Tek accents
                if (step == 2 || step == 6 || step == 10 || step == 14) {
                    val percNote = if (step % 4 == 2) 60 else 62 // Dum vs Tek
                    audioEngine.triggerDrum(percNote, applyVelVariance(0.85f), vol)
                    vus[1] = 0.85f
                }
                // Clap on step 4 & 12 in Variations 2..4
                if ((step == 4 || step == 12) && varIdx >= 2) {
                    audioEngine.triggerDrum(39, applyVelVariance(0.75f), vol)
                    vus[1] = kotlin.math.max(vus[1], 0.75f)
                }
            }
        }

        // --- TRACK 2: BASS ---
        if (isAudible(2)) {
            val vol = tracks[2].volume
            val root = activeChordRoot - 24 // 2 octaves below
            val fifth = root + 7
            val bassHits = when (varIdx) {
                0 -> step == 0 || step == 8
                1 -> step == 0 || step == 6 || step == 8 || step == 12
                else -> step == 0 || step == 4 || step == 6 || step == 8 || step == 10 || step == 14
            }
            if (bassHits) {
                val note = if (step == 8 || step == 10) fifth else root
                audioEngine.triggerArrangerNote(note, ArrangerTrackType.BASS, applyVelVariance(0.85f), 0.22, vol)
                vus[2] = 0.9f
            }
        }

        // --- TRACK 3: ACC1 (Warm Chord Pad) ---
        if (isAudible(3)) {
            val vol = tracks[3].volume
            // Swell pad on measure downbeats
            if (step == 0 || (varIdx >= 2 && step == 8)) {
                val root = activeChordRoot
                audioEngine.triggerArrangerNote(root, ArrangerTrackType.ACC1_PAD, 0.7f, 0.6, vol)
                audioEngine.triggerArrangerNote(root + 7, ArrangerTrackType.ACC1_PAD, 0.6f, 0.6, vol)
                vus[3] = 0.8f
            }
        }

        // --- TRACK 4: ACC2 (Piano Arpeggio / Rhythmic Comping) ---
        if (isAudible(4)) {
            val vol = tracks[4].volume
            if (varIdx >= 1) {
                // Rhythmic piano comping on off-beats
                if (step == 2 || step == 6 || step == 10 || step == 14 || (varIdx >= 3 && step % 2 == 1)) {
                    val arpDegrees = intArrayOf(0, 4, 7, 12)
                    val note = activeChordRoot + arpDegrees[(step / 2) % arpDegrees.size]
                    audioEngine.triggerArrangerNote(note, ArrangerTrackType.ACC2_ARPEGGIATOR, applyVelVariance(0.75f), 0.18, vol)
                    vus[4] = 0.75f
                }
            }
        }

        // --- TRACK 5: ACC3 (Strings Swell) ---
        if (isAudible(5)) {
            val vol = tracks[5].volume
            if (varIdx >= 2 && (step == 0 || step == 8)) {
                audioEngine.triggerArrangerNote(activeChordRoot + 12, ArrangerTrackType.ACC3_STRINGS, 0.75f, 0.55, vol)
                audioEngine.triggerArrangerNote(activeChordRoot + 16, ArrangerTrackType.ACC3_STRINGS, 0.65f, 0.55, vol)
                vus[5] = 0.8f
            }
        }

        // --- TRACK 6: ACC4 (Lead Oriental Synth Accent) ---
        if (isAudible(6)) {
            val vol = tracks[6].volume
            if (varIdx >= 3) {
                // High energy brass/lead hook on steps 3, 7, 11
                if (step == 3 || step == 7 || step == 11) {
                    val leadNote = activeChordRoot + 12 + if (step == 7) 5 else 7
                    audioEngine.triggerArrangerNote(leadNote, ArrangerTrackType.ACC4_LEAD, applyVelVariance(0.85f), 0.24, vol)
                    vus[6] = 0.85f
                }
            }
        }

        // --- TRACK 7: ACC5 (FX / Percussive Accent) ---
        if (isAudible(7)) {
            val vol = tracks[7].volume
            if (varIdx >= 2 && step == 15) {
                // Turnaround fill accent on end of bar
                audioEngine.triggerArrangerNote(activeChordRoot + 19, ArrangerTrackType.ACC5_FX, 0.7f, 0.15, vol)
                vus[7] = 0.7f
            }
        }
    }
}
