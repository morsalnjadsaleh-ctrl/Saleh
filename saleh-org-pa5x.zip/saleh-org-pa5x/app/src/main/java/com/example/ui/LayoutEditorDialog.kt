package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.LayoutConfig
import com.example.ui.theme.Pa5xChassisBorder
import com.example.ui.theme.Pa5xChassisCard
import com.example.ui.theme.Pa5xChassisDark
import com.example.ui.theme.Pa5xMagenta
import com.example.ui.theme.Pa5xNeonCyan
import com.example.ui.theme.Pa5xNeonGreen

@Composable
fun LayoutEditorDialog(
    initialConfig: LayoutConfig,
    onSaveConfig: (LayoutConfig) -> Unit,
    onResetFactory: () -> Unit,
    onDismiss: () -> Unit
) {
    var config by remember { mutableStateOf(initialConfig) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Pa5xChassisDark)
                .border(1.dp, Pa5xMagenta, RoundedCornerShape(10.dp))
                .padding(14.dp)
                .testTag("layout_editor_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CUSTOM LAYOUT EDITOR",
                        color = Pa5xNeonCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "PA5X WORKSPACE PRESET",
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Section 1: Dynamic Scaling Sliders
                Text(
                    text = "SECTION 1: COMPONENT SCALING (RESIZE)",
                    color = Pa5xMagenta,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Monitor scale slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Central Touchscreen Monitor Scale", color = Color.White, fontSize = 9.5.sp)
                        Text(text = "${(config.monitorScale * 100).toInt()}%", color = Pa5xNeonCyan, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = config.monitorScale,
                        onValueChange = { config = config.copy(monitorScale = it) },
                        valueRange = 0.7f..1.3f,
                        colors = SliderDefaults.colors(thumbColor = Pa5xNeonCyan, activeTrackColor = Pa5xNeonCyan),
                        modifier = Modifier.testTag("slider_monitor_scale")
                    )
                }

                // Controls scale slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Hardware Panel & Buttons Scale", color = Color.White, fontSize = 9.5.sp)
                        Text(text = "${(config.controlsScale * 100).toInt()}%", color = Pa5xNeonGreen, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = config.controlsScale,
                        onValueChange = { config = config.copy(controlsScale = it) },
                        valueRange = 0.7f..1.3f,
                        colors = SliderDefaults.colors(thumbColor = Pa5xNeonGreen, activeTrackColor = Pa5xNeonGreen),
                        modifier = Modifier.testTag("slider_controls_scale")
                    )
                }

                // Keyboard height slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Piano Keyboard Height Ratio", color = Color.White, fontSize = 9.5.sp)
                        Text(text = "${(config.keyboardHeightRatio * 100).toInt()}%", color = Color(0xFFFBBF24), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = config.keyboardHeightRatio,
                        onValueChange = { config = config.copy(keyboardHeightRatio = it) },
                        valueRange = 0.25f..0.52f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFFFBBF24), activeTrackColor = Color(0xFFFBBF24)),
                        modifier = Modifier.testTag("slider_keyboard_height")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Section 2: Component Visibility Toggles (ADD/REMOVE)
                Text(
                    text = "SECTION 2: PANEL VISIBILITY (ADD / REMOVE)",
                    color = Pa5xMagenta,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                VisibilitySwitchRow(
                    label = "Pitch Bend & Modulation Wheels",
                    isChecked = config.showPitchBendMod,
                    onCheckedChange = { config = config.copy(showPitchBendMod = it) },
                    testTag = "toggle_pitch_bend"
                )

                VisibilitySwitchRow(
                    label = "8-Track Arranger Mixer Panel",
                    isChecked = config.show8TrackMixer,
                    onCheckedChange = { config = config.copy(show8TrackMixer = it) },
                    testTag = "toggle_mixer"
                )

                VisibilitySwitchRow(
                    label = "Persian Quarter-Tone Quick Bar",
                    isChecked = config.showPersianQuickBar,
                    onCheckedChange = { config = config.copy(showPersianQuickBar = it) },
                    testTag = "toggle_persian"
                )

                VisibilitySwitchRow(
                    label = "AI Drummer Quick Control Box",
                    isChecked = config.showAiDrummerBox,
                    onCheckedChange = { config = config.copy(showAiDrummerBox = it) },
                    testTag = "toggle_ai_drummer"
                )

                VisibilitySwitchRow(
                    label = "Variation 1-4 Hardware Bar",
                    isChecked = config.showVariationBar,
                    onCheckedChange = { config = config.copy(showVariationBar = it) },
                    testTag = "toggle_var_bar"
                )

                VisibilitySwitchRow(
                    label = "Octave Shift Controls",
                    isChecked = config.showOctaveControls,
                    onCheckedChange = { config = config.copy(showOctaveControls = it) },
                    testTag = "toggle_octaves"
                )

                VisibilitySwitchRow(
                    label = "Solfège Note Labels (Do, Re, Mi)",
                    isChecked = config.showPersianKeyLabels,
                    onCheckedChange = { config = config.copy(showPersianKeyLabels = it) },
                    testTag = "toggle_persian_labels"
                )

                VisibilitySwitchRow(
                    label = "English Note Labels (C, D, E)",
                    isChecked = config.showEnglishKeyLabels,
                    onCheckedChange = { config = config.copy(showEnglishKeyLabels = it) },
                    testTag = "toggle_english_labels"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onResetFactory()
                            onDismiss()
                        },
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .testTag("btn_reset_layout")
                    ) {
                        Text(text = "Reset Default", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }

                    Button(
                        onClick = {
                            onSaveConfig(config)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Pa5xMagenta, contentColor = Color.White),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(38.dp)
                            .testTag("btn_save_layout_preset")
                    ) {
                        Text(text = "SAVE PERSONAL PRESET", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun VisibilitySwitchRow(
    label: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFFCBD5E1), fontSize = 9.sp)
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Pa5xNeonCyan,
                checkedTrackColor = Color(0xFF0C4A6E),
                uncheckedThumbColor = Color(0xFF64748B),
                uncheckedTrackColor = Color(0xFF1E293B)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
