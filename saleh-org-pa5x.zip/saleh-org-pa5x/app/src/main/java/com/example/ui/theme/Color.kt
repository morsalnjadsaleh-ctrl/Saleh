package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Korg Pa5X Physical Chassis & Workstation Accent Palette
val Pa5xChassisDark = Color(0xFF101014)
val Pa5xChassisBrushed = Color(0xFF1B1B22)
val Pa5xChassisCard = Color(0xFF23232C)
val Pa5xChassisBorder = Color(0xFF32323E)

// Iconic Pa5X Colors
val Pa5xMagenta = Color(0xFFE91E63)
val Pa5xMagentaDark = Color(0xFF880E4F)
val Pa5xKorgOrange = Color(0xFFFF5722)
val Pa5xRedDivider = Color(0xFFFF1744)
val Pa5xRedGlow = Color(0x66FF1744)
val Pa5xRedFelt = Color(0xFF991B1B)
val Pa5xRedFeltShadow = Color(0xFF450A0A)

// Hardware Texture & Dials
val Pa5xKnurlSilver = Color(0xFF94A3B8)
val Pa5xKnurlHighlight = Color(0xFFF1F5F9)
val Pa5xKnurlDark = Color(0xFF334155)
val Pa5xCheekWood = Color(0xFF141418)
val Pa5xDisplayBezel = Color(0xFF0C0E12)
val Pa5xButtonBevel = Color(0xFF3B3B48)
val Pa5xButtonFace = Color(0xFF282832)

// Workstation Buttons & LED Status Indicators
val Pa5xNeonCyan = Color(0xFF00E5FF)
val Pa5xCyanGlow = Color(0x5500E5FF)
val Pa5xNeonAmber = Color(0xFFFFAB00)
val Pa5xNeonGreen = Color(0xFF00E676)
val Pa5xPersianShor = Color(0xFF76FF03)

// Monitor Display Screen
val Pa5xMonitorBg = Color(0xFF070E16)
val Pa5xMonitorPanel = Color(0xFF0D1B2A)
val Pa5xMonitorGrid = Color(0xFF16283D)
val Pa5xMonitorText = Color(0xFFE0F2FE)
val Pa5xMonitorSubtext = Color(0xFF7DD3FC)

// Piano Keyboard Colors
val Pa5xWhiteKey = Color(0xFFF8FAFC)
val Pa5xWhiteKeyEdge = Color(0xFFE2E8F0)
val Pa5xWhiteKeyPressed = Color(0xFFCBD5E1)
val Pa5xBlackKey = Color(0xFF18181B)
val Pa5xBlackKeyPressed = Color(0xFF3F3F46)
